import { C } from "@/theme";
/**
 * PiezasLaminacionView v5
 *
 * CAMBIOS v5 (sobre v4):
 * — Estados "Enviada" (auto-stampa fecha_envio) y "Recibida" (auto-stampa fecha_recepcion)
 * — Campo "Trayecto" para movimientos entre astilleros (ej: Planta → Astillero Norte)
 * — PDF exporta solo piezas seleccionadas cuando hay selección activa
 * — PDF más conciso: orientación portrait, columnas ajustadas, info de envío integrada
 * — Botón rápido "Enviada ↗" en tabla para piezas terminadas
 *
 * CAMBIOS v4:
 * — Cada pieza con cant > 1 ahora tiene su propia fila
 * — Campo "Laminador" en modal + columna en tabla
 * — Upload de imágenes con manejo de error visible al usuario
 *
 * SQL DE MIGRACIÓN (correr antes de usar v5):
 * ─────────────────────────────────────────────────────────────────
 * -- v4 (si no está ya)
 * ALTER TABLE piezas_laminacion_seguimiento
 * ADD COLUMN IF NOT EXISTS pieza_id  text,
 * ADD COLUMN IF NOT EXISTS laminador text,
 * ADD COLUMN IF NOT EXISTS ubicacion text;
 *
 * UPDATE piezas_laminacion_seguimiento
 * SET pieza_id = pieza_num::text
 * WHERE pieza_id IS NULL;
 *
 * ALTER TABLE piezas_laminacion_seguimiento
 * DROP CONSTRAINT IF EXISTS piezas_laminacion_seguimiento_obra_id_pieza_num_key;
 * ALTER TABLE piezas_laminacion_seguimiento
 * ADD CONSTRAINT pls_obra_pieza_unique UNIQUE (obra_id, pieza_id);
 *
 * ALTER TABLE piezas_laminacion_imagenes
 * ADD COLUMN IF NOT EXISTS pieza_id text;
 * UPDATE piezas_laminacion_imagenes
 * SET pieza_id = pieza_num::text
 * WHERE pieza_id IS NULL;
 *
 * -- v5: envío / recepción / trayecto
 * ALTER TABLE piezas_laminacion_seguimiento
 * ADD COLUMN IF NOT EXISTS fecha_envio      timestamptz,
 * ADD COLUMN IF NOT EXISTS fecha_recepcion  timestamptz,
 * ADD COLUMN IF NOT EXISTS trayecto         text;
 * ─────────────────────────────────────────────────────────────────
 */

import { useEffect, useMemo, useState, useCallback } from "react";
import { supabase } from "@/supabaseClient";
import { useResponsive } from "@/hooks/useResponsive";
import Cargando from "@/components/ui/Cargando";
import PiezasLaminacionFotos, { FotoPieza } from "./PiezasLaminacionFotos";
import { PIEZAS_FOTOS_BUCKET as STORAGE_BUCKET } from "./piezasLaminacionFotosApi";

const GLASS = {
  backdropFilter:"blur(24px) saturate(130%)",
  WebkitBackdropFilter:"blur(24px) saturate(130%)",
};


const EST = {
  pendiente:  { label:"Pendiente",  color:C.t2,     bg:"rgba(113,113,122,.10)", border:"rgba(113,113,122,.22)" },
  en_proceso: { label:"En proceso", color:C.blue,   bg:"rgba(59,130,246,.10)",  border:"rgba(59,130,246,.25)"  },
  terminada:  { label:"Terminada",  color:C.green,  bg:"rgba(16,185,129,.10)",  border:"rgba(16,185,129,.25)"  },
  enviada:    { label:"Enviada",    color:C.cyan,  bg:"rgba(34,211,238,.10)",  border:"rgba(34,211,238,.28)"  },
  recibida:   { label:"Recibida",   color:"#2dd4bf",bg:"rgba(45,212,191,.10)",  border:"rgba(45,212,191,.28)"  },
  entregada:  { label:"Entregada",  color:C.purple, bg:"rgba(139,92,246,.10)",  border:"rgba(139,92,246,.25)"  },
  problema:   { label:"Problema",   color:C.red,    bg:"rgba(239,68,68,.10)",   border:"rgba(239,68,68,.25)"   },
};

const OBRA_COLOR = {
  activa:"#3b82f6", pausada:"#8b5cf6", terminada:"#10b981", cancelada:"#ef4444",
};

// ─── catalogo helpers ─────────────────────────────────────────────────────────
function makePiezaId(num, sub) { return sub != null ? `${num}/${sub}` : `${num}`; }

function expandCatalogo(raw) {
  const result = [];
  for (const r of raw) {
    if (r.cant === 1) {
      result.push({ pieza_id: makePiezaId(r.num, null), num: r.num, sub: null, desc: r.desc, matriz: r.matriz ?? null, variant: r.variant ?? null });
    } else {
      for (let i = 1; i <= r.cant; i++) {
        result.push({ pieza_id: makePiezaId(r.num, i), num: r.num, sub: i, desc: r.desc, matriz: r.matriz ?? null, variant: r.variant ?? null });
      }
    }
  }
  return result;
}

// ─── catálogos raw ────────────────────────────────────────────────────────────
const RAW_K43 = [
  { num:1,  desc:"Casco",                                        cant:1, matriz:null },
  { num:2,  desc:"Cubierta",                                     cant:1, matriz:null },
  { num:3,  desc:"Cabina",                                       cant:1, matriz:null },
  { num:5,  desc:"Planchada lado inferior",                      cant:1, matriz:null },
  { num:6,  desc:"Planchada Nueva",                              cant:1, matriz:null },
  { num:7,  desc:"Laterales de planchada nueva",                 cant:2, matriz:null },
  { num:8,  desc:"Piso de cockpit",                              cant:1, matriz:null },
  { num:9,  desc:"Tapa de sala de maquinas",                     cant:1, matriz:"Nueva #20" },
  { num:10, desc:"Tacho de mueble lateral de cockpit estribor",  cant:1, matriz:"Nueva #20" },
  { num:11, desc:"Tacho de mueble lateral de cockpit babor",     cant:1, matriz:"Nueva #20" },
  { num:12, desc:"Puerta del tacho lateral de cockpit Estribor", cant:1, matriz:null },
  { num:13, desc:"Puerta del tacho lateral de cockpit Babor",    cant:1, matriz:null },
  { num:14, desc:"Pasacabos de popa Estribor",                   cant:1, matriz:"Nueva #20" },
  { num:15, desc:"Pasacabos de popa Babor",                      cant:1, matriz:"Nueva #20" },
  { num:16, desc:"Tomas de aire",                                cant:2, matriz:null },
  { num:17, desc:"Sillon de cockpit",                            cant:1, matriz:"Nueva #20" },
  { num:18, desc:"Tapa de parrilla",                             cant:1, matriz:null },
  { num:19, desc:"Base de sillon de cockpit",                    cant:1, matriz:"Nueva #20" },
  { num:20, desc:"Tapa de tacho de planchada",                   cant:1, matriz:null },
  { num:21, desc:"Tapa de tacho de proa estribor",               cant:1, matriz:"Nueva #20" },
  { num:22, desc:"Tapa de tacho de proa Babor",                  cant:1, matriz:"Nueva #20" },
  { num:23, desc:"Tacho de proa",                                cant:1, matriz:null },
  { num:24, desc:"Tapa de malacate",                             cant:1, matriz:null },
  { num:25, desc:"Cuchara de extractores",                       cant:2, matriz:null },
  { num:26, desc:"Consola de fly",                               cant:1, matriz:"Nueva #20" },
  { num:27, desc:"Consola salon",                                cant:1, matriz:null },
  { num:28, desc:"Tapa escalera fly",                            cant:1, matriz:"Nueva #20" },
  { num:29, desc:"Base de butaca Fly",                           cant:1, matriz:"Nueva #20" },
  { num:30, desc:"Arco Radar",                                   cant:1, matriz:"Nueva #20" },
  { num:31, desc:"Tapa de arco Radar Central",                   cant:1, matriz:"Nueva #20" },
  { num:32, desc:"Tapa de arco Radar Estribor",                  cant:1, matriz:"Nueva #20" },
  { num:33, desc:"Tapa de arco Radar Babor",                     cant:1, matriz:"Nueva #20" },
  { num:34, desc:"Camarote de proa",                             cant:1, matriz:null },
  { num:35, desc:"Techo de camarote de proa",                    cant:1, matriz:null },
  { num:36, desc:"Baño de babor",                                cant:1, matriz:null },
  { num:37, desc:"Techo de baño de babor",                       cant:1, matriz:null },
  { num:38, desc:"Banda de baño de babor",                       cant:1, matriz:null },
  { num:39, desc:"Baño de estribor",                             cant:1, matriz:null },
  { num:40, desc:"Techo de baño de estribor",                    cant:1, matriz:null },
  { num:41, desc:"Banda baño estribor",                          cant:1, matriz:null },
  { num:42, desc:"Marco ventana baño estribor",                  cant:1, matriz:null },
  { num:43, desc:"Camarote de estribor",                         cant:1, matriz:null },
  { num:44, desc:"Techo camarote de estribor",                   cant:1, matriz:null },
  { num:45, desc:"Camarote de popa",                             cant:1, matriz:null },
  { num:46, desc:"Techo camarote de popa",                       cant:2, matriz:null },
  { num:47, desc:"Banda de salon proa estribor",                 cant:1, matriz:"Nueva #20" },
  { num:48, desc:"Banda de salon popa estribor",                 cant:1, matriz:"Nueva #20" },
  { num:49, desc:"Banda de salon popa Babor",                    cant:1, matriz:"Nueva #20" },
  { num:50, desc:"Banda de salon proa Babor",                    cant:1, matriz:"Nueva #20" },
  { num:51, desc:"Interior escalera Fly",                        cant:1, matriz:"Nueva #20" },
  { num:52, desc:"Moldura pasillo",                              cant:1, matriz:"Nueva #20" },
  { num:53, desc:"Contratecho cabina proa",                      cant:1, matriz:null },
  { num:54, desc:"Contratecho cockpit",                          cant:1, matriz:"Nueva #20" },
  { num:55, desc:"Cajon de baterías",                            cant:1, matriz:null },
  { num:56, desc:"Tapa Cajon de baterías",                       cant:1, matriz:null },
  { num:57, desc:"Tapa de escalera de planchada",                cant:1, matriz:"Nueva #20" },
  { num:58, desc:"Caja de selectoras",                           cant:1, matriz:null },
  { num:59, desc:"Mesa de fly",                                  cant:1, matriz:null },
  { num:60, desc:"Cenefa larga",                                    cant:1, matriz:null },
  { num:61, desc:"Cenefa corta",                                    cant:1, matriz:null },
  { num:62, desc:"Piso baño estribor",                              cant:1, matriz:null },
  { num:63, desc:"Piso baño babor",                                 cant:1, matriz:null },
];

// variant: "softop" | "hardtop" | null (null = ambos)
const RAW_K52 = [
  { num:1,  desc:"Casco",                                                  cant:1,  variant:null      },
  { num:2,  desc:"Cubierta",                                               cant:1,  variant:null      },
  { num:3,  desc:"Interior de popa",                                       cant:1,  variant:null      },
  { num:4,  desc:"Interior de proa",                                       cant:1,  variant:null      },
  { num:5,  desc:"Mamparo de baño de popa",                                cant:1,  variant:null      },
  { num:6,  desc:"Mamparo de baño de proa",                                cant:1,  variant:null      },
  { num:7,  desc:"Techo de baño de popa",                                  cant:1,  variant:null      },
  { num:8,  desc:"Techo de baño de proa",                                  cant:1,  variant:null      },
  { num:9,  desc:"Cenefa de baño, baño de popa y proa",                    cant:2,  variant:null      },
  { num:10, desc:"Moldura de entrada de salón",                            cant:1,  variant:null      },
  { num:11, desc:"Moldura de ventana de babor, salón",                     cant:1,  variant:null      },
  { num:12, desc:"Moldura de ventana de estribor, salón",                  cant:1,  variant:null      },
  { num:13, desc:"Cenefa de babor, salón",                                 cant:3,  variant:null      },
  { num:14, desc:"Cenefa de estribor, salón",                              cant:1,  variant:null      },
  { num:15, desc:"Moldura de ventana de babor, camarote de popa",          cant:1,  variant:null      },
  { num:16, desc:"Moldura de ventana de estribor, camarote de popa",       cant:1,  variant:null      },
  { num:17, desc:"Cenefa, camarote de proa",                               cant:1,  variant:null      },
  { num:18, desc:"Moldura de ventana de estribor, camarote de proa",       cant:1,  variant:null      },
  { num:19, desc:"Moldura de ventana de babor, camarote de proa",          cant:1,  variant:null      },
  { num:22, desc:"Sobre apoyo de consola",                                 cant:1,  variant:null      },
  { num:23, desc:"Moldura de pasamanos de sobre apoyo de consola",         cant:1,  variant:null      },
  { num:24, desc:"Consola",                                                cant:1,  variant:null      },
  { num:25, desc:"Máscara tapizada de cleopatra, cockpit",                 cant:1,  variant:null      },
  { num:26, desc:"Máscara tapizada de dinnette, cockpit",                  cant:1,  variant:null      },
  { num:27, desc:"Mueble de cockpit",                                      cant:1,  variant:null      },
  { num:28, desc:"Tapa de tele de mueble de cockpit",                      cant:1,  variant:null      },
  { num:29, desc:"Tapa de parrilla de mueble de cockpit",                  cant:1,  variant:null      },
  { num:30, desc:"Puertita de popa de mueble de cockpit",                  cant:1,  variant:null      },
  { num:31, desc:"Puertita de proa de mueble de cockpit",                  cant:1,  variant:null      },
  { num:32, desc:"Caja de selectoras, cockpit",                            cant:1,  variant:null      },
  { num:33, desc:"Softop",                                                 cant:1,  variant:"softop"  },
  { num:34, desc:"Hardtop",                                                cant:1,  variant:"hardtop" },
  { num:35, desc:"Cáscara de planchada tender",                            cant:1,  variant:null      },
  { num:36, desc:"Planchada fija",                                         cant:1,  variant:null      },
  { num:37, desc:"Túnel de escape de planchada fija",                      cant:2,  variant:null      },
  { num:38, desc:"Cacha de estribor de planchada",                         cant:1,  variant:null      },
  { num:39, desc:"Cacha de babor de planchada",                            cant:1,  variant:null      },
  { num:40, desc:"Baúl, cara inferior",                                    cant:1,  variant:null      },
  { num:41, desc:"Baúl, cara superior",                                    cant:1,  variant:null      },
  { num:42, desc:"Tapa de baúl",                                           cant:1,  variant:null      },
  { num:43, desc:"Toma de aire de babor",                                  cant:1,  variant:null      },
  { num:44, desc:"Toma de aire de estribor",                               cant:1,  variant:null      },
  { num:45, desc:"Base de brújula",                                        cant:1,  variant:null      },
  { num:46, desc:"Tapa de caja de cadenas",                                cant:1,  variant:null      },
  { num:47, desc:"Tapa de escalera de planchada",                          cant:1,  variant:null      },
  { num:48, desc:"Cajón de baterías grande",                               cant:1,  variant:null      },
  { num:49, desc:"Cajón de baterías chico 1",                              cant:1,  variant:null      },
  { num:50, desc:"Cajón de baterías chico 2",                              cant:1,  variant:null      },
  { num:51, desc:"Imbornales altos",                                       cant:12, variant:null      },
  { num:52, desc:"Caja de aire acondicionado 1",                           cant:1,  variant:null      },
  { num:53, desc:"Caja de aire acondicionado 2",                           cant:1,  variant:null      },
  { num:54, desc:"Contratecho softop",                                     cant:1,  variant:"softop"  },
  { num:55, desc:"Contratecho hardtop",                                    cant:1,  variant:"hardtop" },
  { num:56, desc:"Laminado de cuadernas transversales",                    cant:1,  variant:null      },
  { num:57, desc:"Laminado de largueros longitudinales",                   cant:1,  variant:null      },
  { num:58, desc:"Laminado de grilla de softop",                           cant:1,  variant:"softop"  },
  { num:59, desc:"Laminado de grilla de cubierta",                         cant:1,  variant:null      },
  { num:60, desc:"Tambucho de proa",                                       cant:1,  variant:null      },
  { num:61, desc:"Tapa de sala de máquinas",                               cant:1,  variant:null      },
  { num:62, desc:"Pata de estribor de hardtop",                            cant:1,  variant:"hardtop" },
  { num:63, desc:"Pata de babor de hardtop",                               cant:1,  variant:"hardtop" },
  { num:64, desc:"Moldura de ventana de baño de proa",                     cant:1,  variant:null      },
  { num:65, desc:"Moldura de ventana de baño de popa",                     cant:1,  variant:null      },
  { num:66, desc:"Cara 1 de parante longitudinal de estribor, softop",     cant:1,  variant:"softop"  },
  { num:67, desc:"Cara 2 de parante longitudinal de estribor, softop",     cant:1,  variant:"softop"  },
  { num:68, desc:"Cara 1 de parante longitudinal de babor, softop",        cant:1,  variant:"softop"  },
  { num:69, desc:"Cara 2 de parante longitudinal de babor, softop",        cant:1,  variant:"softop"  },
  { num:70, desc:"Cara 1 de parante transversal de softop",                cant:1,  variant:"softop"  },
  { num:71, desc:"Cara 2 de parante transversal de softop",                cant:1,  variant:"softop"  },
];

const RAW_K37 = [
  { num:  1, desc: "Casco",                                       cant: 1, matriz: null },
  { num:  2, desc: "Postizo de ventana de babor",                 cant: 1, matriz: null },
  { num:  3, desc: "Postizo de ventana de estribor",              cant: 1, matriz: null },
  { num:  4, desc: "Postizo cajón",                               cant: 1, matriz: null },
  { num:  5, desc: "Cubierta",                                    cant: 1, matriz: null },
  { num:  6, desc: "Techo ST",                                    cant: 4, matriz: null },
  { num:  7, desc: "Plafón de techo",                             cant: 1, matriz: null },
  { num:  8, desc: "Interior (piso)",                             cant: 1, matriz: null },
  { num:  9, desc: "Mesa de cockpit",                             cant: 1, matriz: "Compartida K42/K43" },
  { num: 10, desc: "Consola",                                     cant: 2, matriz: null },
  { num: 11, desc: "Solarium de popa",                            cant: 5, matriz: null },
  { num: 12, desc: "Tapa de parrilla",                            cant: 1, matriz: null },
  { num: 13, desc: "Tacho de parrilla",                           cant: 1, matriz: null },
  { num: 14, desc: "Tapa entrada a S.M. solarium de popa",        cant: 1, matriz: null },
  { num: 15, desc: "Tacho de solarium de popa",                   cant: 1, matriz: null },
  { num: 16, desc: "Tapa entrada a sala de máquinas grande",      cant: 1, matriz: null },
  { num: 17, desc: "Cajón de baterías",                           cant: 1, matriz: "Compartida K42/K43" },
  { num: 18, desc: "Tapa cajón de baterías",                      cant: 1, matriz: "Compartida K42/K43" },
  { num: 19, desc: "Mueble de cockpit",                           cant: 4, matriz: null },
  { num: 20, desc: "Tapa malacate",                               cant: 2, matriz: null },
  { num: 21, desc: "Caja selectora",                              cant: 1, matriz: null },
  { num: 22, desc: "Toma de aire de estribor",                    cant: 1, matriz: null },
  { num: 23, desc: "Toma de aire de babor",                       cant: 1, matriz: null },
  { num: 24, desc: "Tapa cajón de planchada",                     cant: 1, matriz: null },
  { num: 25, desc: "Tapa escalera de sala de máquinas",           cant: 1, matriz: null },
  { num: 26, desc: "Liner de ventana conejera estribor",          cant: 1, matriz: null },
  { num: 27, desc: "Liner de ventana conejera babor",             cant: 1, matriz: null },
  { num: 28, desc: "Liner de ventana cocina estribor",            cant: 1, matriz: null },
  { num: 29, desc: "Liner de ventana salón babor",                cant: 1, matriz: null },
  { num: 30, desc: "Liner de ventana baño estribor",              cant: 1, matriz: null },
  { num: 31, desc: "Liner de ventana camarote de proa estribor",  cant: 1, matriz: null },
  { num: 32, desc: "Liner de ventana camarote de proa babor",     cant: 1, matriz: null },
  { num: 33, desc: "Mamparo de baño",                             cant: 1, matriz: null },
];

const RAW_K55 = [
  { num: 1,  desc: "Casco",                                      cant: 1, matriz: "Matriz lista" },
  { num: 2,  desc: "Cubierta",                                   cant: 1, matriz: "Matriz lista, agregar tortitas baranda y plano solarium proa" },
  { num: 3,  desc: "Flybridge",                                  cant: 1, matriz: "Matriz lista" },
  { num: 4,  desc: "Solarium cubierta proa",                     cant: 1, matriz: "Hacer modelo con modificaciones y matrizar" },
  { num: 5,  desc: "Tacho de guarda bajo asiento parabrisas",    cant: 1, matriz: "Matriz lista, agregar una brida para sacarle una pared" },
  { num: 6,  desc: "Piso de cockpit",                            cant: 1, matriz: "Matriz lista" },
  { num: 7,  desc: "Tapa piso de cockpit",                       cant: 1, matriz: "Hacer modelo y matriz; pieza vino mal (83x83cm)" },
  { num: 8,  desc: "Porton de sala maquinas",                    cant: 1, matriz: "Matriz lista, en Chubut" },
  { num: 9,  desc: "Puerta de camarote marinero",                cant: 1, matriz: "Terminar matriz y poner refuerzos" },
  { num: 10, desc: "Mueble de flybridge",                        cant: 1, matriz: "Terminada matriz parte superior; falta parte inferior" },
  { num: 11, desc: "Tapa de mueble flybridge",                   cant: 1, matriz: "Terminar matriz y poner refuerzos" },
  { num: 12, desc: "Puerta de flybridge",                        cant: 1, matriz: "Terminar matriz y poner refuerzos" },
  { num: 13, desc: "Asiento de flybridge",                       cant: 1, matriz: "Terminar matriz y poner refuerzos" },
  { num: 14, desc: "Consola flybridge",                          cant: 1, matriz: "Ver si se puede usar de otro barco, 64?" },
  { num: 15, desc: "Arco radar",                                 cant: 1, matriz: "Armando modelo en Chubut" },
  { num: 16, desc: "Contra techo cockpit",                       cant: 1, matriz: "Puliendo matriz" },
  { num: 17, desc: "Balcon Estribor",                            cant: 1, matriz: "Hacer matriz, modelos en Chubut" },
  { num: 18, desc: "Balcon Babor",                               cant: 1, matriz: "Hacer matriz, modelos en Chubut" },
  { num: 19, desc: "Planchada",                                  cant: 1, matriz: "Modificar matriz inferior para abrir desagotes agua" },
  { num: 20, desc: "Tapa de malacate",                           cant: 1, matriz: "Matriz lista" },
  { num: 21, desc: "Tapas de solarium proa",                     cant: 6, matriz: "Matriz lista" },
  { num: 22, desc: "Tachos de guarda en popa",                   cant: 2, matriz: "Terminar matriz y poner refuerzos" },
  { num: 23, desc: "Tapas de tachos de guarda en popa",          cant: 2, matriz: "Hacer modelo y matrizar" },
  { num: 24, desc: "Liner interior",                             cant: 1, matriz: "Matriz lista, en Pampa" },
  { num: 25, desc: "Aro de tambucho de proa",                    cant: 1, matriz: "Matrizar la pieza que esta en Pampa" },
  { num: 26, desc: "Escalon en techo de salon",                  cant: 1, matriz: "Matriz en proceso, terminar y poner refuerzos" },
  { num: 27, desc: "Consola vertical (para plotter)",            cant: 1, matriz: "Terminar matriz y poner refuerzos" },
  { num: 28, desc: "Consola horizontal (para comando)",          cant: 1, matriz: "Terminar matriz y poner refuerzos" },
  { num: 29, desc: "Torpedo salon",                              cant: 1, matriz: "Modelo casi terminado, matrizar" },
  { num: 30, desc: "Fondo de solarium proa - NO SE USA MAS",     cant: 1, matriz: "NO SE USA MAS" },
  { num: 31, desc: "Moldura (cenefa) interior, matriz RECTA",    cant: 1, matriz: "Matriz lista" },
  { num: 32, desc: "Moldura (cenefa) interior, curva para proa", cant: 1, matriz: "Matriz lista" },
  { num: 33, desc: "Techo de bano proa",                         cant: 1, matriz: "Matriz lista" },
  { num: 34, desc: "Piso de bano proa - NO SE USA MAS",          cant: 1, matriz: "NO SE USA MAS, viene liner" },
  { num: 35, desc: "Contra techo salon",                         cant: 1, matriz: "Disenar, hacer modelo y matriz" },
];

const CATALOGOS = {
  k37: expandCatalogo(RAW_K37),
  k43: expandCatalogo(RAW_K43),
  k52: expandCatalogo(RAW_K52),
  k55: expandCatalogo(RAW_K55),
};

function detectarLinea(obra) {
  if (!obra) return null;
  const cod = (obra.codigo ?? "").toLowerCase();
  const lin = (obra.linea_nombre ?? "").toLowerCase();
  if (cod.includes("55") || lin.includes("55")) return "k55";
  if (cod.includes("52") || lin.includes("52")) return "k52";
  if (cod.includes("43") || lin.includes("43")) return "k43";
  if (cod.includes("37") || lin.includes("37")) return "k37";
  return null;
}

// ─── icons ────────────────────────────────────────────────────────────────────
const IconCamera = ({ size=14, color="currentColor" }) => (
  <svg width={size} height={size} viewBox="0 0 20 20" fill="none" stroke={color} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
    <path d="M2 7.5C2 6.4 2.9 5.5 4 5.5h1.17a1 1 0 0 0 .77-.36l1.12-1.28A1 1 0 0 1 7.83 3.5h4.34a1 1 0 0 1 .77.36l1.12 1.28a1 1 0 0 0 .77.36H16c1.1 0 2 .9 2 2v7c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2v-7Z"/>
    <circle cx="10" cy="11" r="2.5"/>
  </svg>
);
const IconCheck = ({ size=10 }) => (
  <svg width={size} height={size} viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="2,7 5.5,10.5 12,3"/>
  </svg>
);

// ─── atoms ────────────────────────────────────────────────────────────────────
function Dot({ color, size=6, pulse=false }) {
  return <div style={{ width:size, height:size, borderRadius:"50%", background:color, flexShrink:0, animation:pulse?"plv-pulse 2s ease infinite":"none", boxShadow:pulse?`0 0 5px ${color}70`:"none" }} />;
}
function Chip({ estado, sm=false }) {
  const e = EST[estado] ?? EST.pendiente;
  return <span style={{ fontSize:sm?8:9, letterSpacing:1.1, textTransform:"uppercase", padding:sm?"2px 6px":"3px 9px", borderRadius:99, fontWeight:600, background:e.bg, color:e.color, border:`1px solid ${e.border}`, whiteSpace:"nowrap", fontFamily:C.sans }}>{e.label}</span>;
}
function ProgressRing({ pct, size=44, stroke=3.5, color=C.green }) {
  const r = (size-stroke*2)/2, circ = 2*Math.PI*r;
  return (
    <svg width={size} height={size} style={{ transform:"rotate(-90deg)", flexShrink:0 }}>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="var(--panel-2)" strokeWidth={stroke} />
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round"
        strokeDasharray={`${(pct/100)*circ} ${circ}`} style={{ transition:"stroke-dasharray .7s cubic-bezier(.22,1,.36,1)" }} />
    </svg>
  );
}
function KpiCard({ label, value, total, color, delay=0 }) {
  const p = total > 0 ? Math.round(value/total*100) : 0;
  return (
    <div title={`${label}: ${value} de ${total} piezas (${p}%)`} style={{ minWidth:0, background:C.s0, border:`1px solid ${C.b0}`, borderRadius:7, padding:"5px 7px", borderLeft:`2px solid ${color}`, animation:`plv-kpi .35s ${delay}s ease both` }}>
      <div style={{ fontSize:10, color:C.t2, lineHeight:1.2, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{label}</div>
      <div style={{ display:"flex", alignItems:"baseline", gap:5, marginTop:3 }}>
        <span style={{ fontFamily:C.mono, fontSize:16, fontWeight:600, color, lineHeight:1 }}>{value}</span>
        <span style={{ fontSize:10, color:C.t2, lineHeight:1 }}>{p}%</span>
      </div>
    </div>
  );
}

// ─── lightbox ────────────────────────────────────────────────────────────────
function fechaCorta(ts) {
  if (!ts) return null;
  return new Date(ts).toLocaleDateString("es-AR", { day:"2-digit", month:"2-digit" });
}

function PiezaFlowCard({ pieza, seg, imagenes=[], esGestion, saving, selected=false, onToggle, onEstado, onDetalle }) {
  const estado = seg?.estado ?? "pendiente";
  const estInfo = EST[estado] ?? EST.pendiente;
  const fechaEnvio = fechaCorta(seg?.fecha_envio);
  const fechaRecepcion = fechaCorta(seg?.fecha_recepcion);
  return (
    <div className={`plv-flow-card${selected ? " plv-card-sel" : ""}`} style={{ border:`1px solid ${selected ? "rgba(59,130,246,0.55)" : C.b0}`, borderLeft:`3px solid ${estInfo.color}`, background:selected ? "rgba(59,130,246,0.08)" : "var(--panel)", borderRadius:8, padding:"9px 10px", display:"grid", gap:7 }}>
      <div style={{ display:"flex", alignItems:"center", gap:7 }}>
        <input type="checkbox" className="plv-check" checked={selected} onChange={onToggle} />
        <span style={{ fontFamily:C.mono, fontSize:11, color:C.t2, minWidth:28 }}>{pieza.pieza_id}</span>
        <Chip estado={estado} sm />
        {imagenes.length > 0 && <span style={{ fontSize:10, color:C.t2, marginLeft:"auto" }}>{imagenes.length} foto{imagenes.length>1?"s":""}</span>}
      </div>
      <button onClick={onDetalle} style={{ background:"transparent", border:0, padding:0, cursor:"pointer", textAlign:"left", fontFamily:C.sans }}>
        <div style={{ fontSize:13, color:C.t0, fontWeight:600, lineHeight:1.3 }}>{pieza.desc}</div>
        {pieza.matriz && <div style={{ marginTop:4, fontSize:11, color:C.t2, lineHeight:1.35 }}>{pieza.matriz}</div>}
      </button>
      {imagenes.length > 0 ? <FotoPieza key={imagenes[0].storage_path} foto={imagenes[0]} descripcion={pieza.desc} onClick={onDetalle} style={{ height:128 }} /> : null}
      <button onClick={onDetalle} style={{ display:"flex", alignItems:"center", justifyContent:"center", gap:6, border:`1px ${imagenes.length ? "solid" : "dashed"} ${C.b0}`, borderRadius:7, background:C.s0, color:C.t1, cursor:"pointer", padding:"8px", fontSize:11, fontFamily:C.sans }}>
        <IconCamera size={14} color="currentColor"/>{imagenes.length ? `Ver fotos (${imagenes.length}) · Agregar` : "Agregar fotos de referencia"}
      </button>
      {(seg?.laminador || seg?.ubicacion || seg?.trayecto || fechaEnvio || fechaRecepcion) && (
        <div style={{ display:"grid", gap:3, paddingTop:6, borderTop:`1px solid ${C.b0}` }}>
          {seg?.laminador && <div style={{ fontSize:11, color:C.t2 }}>Laminador: <span style={{ color:C.t1 }}>{seg.laminador}</span></div>}
          {seg?.ubicacion && <div style={{ fontSize:11, color:C.t2 }}>Ubicacion: <span style={{ color:C.t1 }}>{seg.ubicacion}</span></div>}
          {seg?.trayecto && <div style={{ fontSize:11, color:C.t2 }}>Trayecto: <span style={{ color:C.t1 }}>{seg.trayecto}</span></div>}
          {(fechaEnvio || fechaRecepcion) && (
            <div style={{ fontSize:11, color:C.t2 }}>
              {fechaEnvio && <span>Envio {fechaEnvio}</span>}
              {fechaEnvio && fechaRecepcion && <span> · </span>}
              {fechaRecepcion && <span>Recepcion {fechaRecepcion}</span>}
            </div>
          )}
        </div>
      )}
      {esGestion && (
        <div style={{ display:"flex", gap:5, flexWrap:"wrap" }}>
          {estado !== "terminada" && <button className="plv-qbtn" disabled={saving} onClick={() => onEstado("terminada")} style={{ border:"1px solid rgba(16,185,129,0.3)", background:"rgba(16,185,129,0.08)", color:"#34d399", padding:"4px 7px", borderRadius:5, cursor:"pointer", fontSize:11, fontWeight:600 }}>Lista</button>}
          {estado !== "enviada" && <button className="plv-qbtn" disabled={saving} onClick={() => onEstado("enviada")} style={{ border:"1px solid rgba(34,211,238,0.3)", background:"rgba(34,211,238,0.08)", color:C.cyan, padding:"4px 7px", borderRadius:5, cursor:"pointer", fontSize:11, fontWeight:600 }}>Enviar</button>}
          {estado !== "recibida" && <button className="plv-qbtn" disabled={saving} onClick={() => onEstado("recibida")} style={{ border:"1px solid rgba(45,212,191,0.3)", background:"rgba(45,212,191,0.08)", color:"#2dd4bf", padding:"4px 7px", borderRadius:5, cursor:"pointer", fontSize:11, fontWeight:600 }}>Recibir</button>}
          <button className="plv-qbtn" onClick={onDetalle} style={{ marginLeft:"auto", border:`1px solid ${C.b0}`, background:"transparent", color:C.t2, padding:"4px 7px", borderRadius:5, cursor:"pointer", fontSize:11 }}>Detalle</button>
        </div>
      )}
    </div>
  );
}

function RecepcionColumn({ title, subtitle, color, piezas, segMap, imagenesMap, esGestion, saving, selected, onToggle, onEstado, onDetalle }) {
  return (
    <section style={{ minWidth:0, borderTop:`2px solid ${color}`, background:"var(--panel)", display:"flex", flexDirection:"column", minHeight:0 }}>
      <div style={{ padding:"10px 11px", borderBottom:`1px solid ${C.b0}` }}>
        <div style={{ display:"flex", alignItems:"center", gap:7 }}>
          <Dot color={color} size={6} />
          <div style={{ fontSize:12, color:C.t0, fontWeight:650, letterSpacing:.5, textTransform:"uppercase" }}>{title}</div>
          <div style={{ marginLeft:"auto", fontFamily:C.mono, fontSize:14, color }}>{piezas.length}</div>
        </div>
        <div style={{ fontSize:10, color:C.t2, marginTop:3, lineHeight:1.3 }}>{subtitle}</div>
      </div>
      <div style={{ flex:1, overflowY:"auto", padding:8, display:"grid", gap:7, alignContent:"start" }}>
        {piezas.length === 0 ? (
          <div style={{ border:`1px dashed ${C.b0}`, borderRadius:8, padding:"18px 10px", textAlign:"center", color:C.t2, fontSize:11 }}>Sin piezas</div>
        ) : piezas.map(pieza => (
          <PiezaFlowCard
            key={pieza.pieza_id}
            pieza={pieza}
            seg={segMap[pieza.pieza_id]}
            imagenes={imagenesMap[pieza.pieza_id] ?? []}
            esGestion={esGestion}
            saving={saving}
            selected={selected.has(pieza.pieza_id)}
            onToggle={() => onToggle(pieza.pieza_id)}
            onEstado={(estado) => onEstado([pieza.pieza_id], estado)}
            onDetalle={() => onDetalle(pieza)}
          />
        ))}
      </div>
    </section>
  );
}

const LINE_ORDER = ["k55", "k52", "k43", "k37", "otros"];
const LINE_META = {
  k55: { label:"K55", color:C.blue },
  k52: { label:"K52", color:C.purple },
  k43: { label:"K43", color:C.cyan },
  k37: { label:"K37", color:"#2dd4bf" },
  otros: { label:"Sin linea", color:C.t2 },
};

function resumenObraPiezas(obra, seguimientoPorObra) {
  const linea = detectarLinea(obra);
  const catalogoObra = linea ? CATALOGOS[linea] ?? [] : [];
  const estados = seguimientoPorObra?.[obra.id] ?? {};
  const byEst = {};
  for (const key of Object.keys(EST)) byEst[key] = 0;
  for (const pieza of catalogoObra) {
    const estado = estados[pieza.pieza_id] ?? "pendiente";
    byEst[estado] = (byEst[estado] ?? 0) + 1;
  }
  const total = catalogoObra.length;
  const listas = (byEst.terminada ?? 0) + (byEst.enviada ?? 0) + (byEst.recibida ?? 0) + (byEst.entregada ?? 0);
  const recibidas = (byEst.recibida ?? 0) + (byEst.entregada ?? 0);
  return {
    linea: linea ?? "otros",
    total,
    listas,
    recibidas,
    problemas: byEst.problema ?? 0,
    pct: total ? Math.round((listas / total) * 100) : 0,
    pctRecibidas: total ? Math.round((recibidas / total) * 100) : 0,
  };
}

// ─── modal pieza ─────────────────────────────────────────────────────────────
function PiezaModal({ pieza, lineaKey, obraId, segRow, imagenes=[], onImagenesChange, onSave, onClose }) {
  const [estado,         setEstadoRaw]    = useState(segRow?.estado ?? "pendiente");
  const [obs,            setObs]          = useState(segRow?.observaciones ?? "");
  const [ubicacion,      setUbicacion]    = useState(segRow?.ubicacion ?? "");
  const [laminador,      setLaminador]    = useState(segRow?.laminador ?? "");
  const [trayecto,       setTrayecto]     = useState(segRow?.trayecto ?? "");
  const [fechaEnvio,     setFechaEnvio]   = useState(segRow?.fecha_envio ? new Date(segRow.fecha_envio).toISOString().slice(0,10) : "");
  const [fechaRecepcion, setFechaRecepcion] = useState(segRow?.fecha_recepcion ? new Date(segRow.fecha_recepcion).toISOString().slice(0,10) : "");
  const [saving,    setSaving]    = useState(false);
  const [fotosBusy, setFotosBusy] = useState(false);
  const [uploadErr, setUploadErr] = useState("");

  function setEstado(val) {
    setEstadoRaw(val);
    // auto-stamp fechas si no están ya
    if (val === "enviada"  && !fechaEnvio)     setFechaEnvio(new Date().toISOString().slice(0,10));
    if (val === "recibida" && !fechaRecepcion) setFechaRecepcion(new Date().toISOString().slice(0,10));
  }

  async function guardar() {
    setSaving(true);
    const { data:{ session } } = await supabase.auth.getSession().catch(() => ({ data:{ session:null } }));
    const user = session?.user ?? null;
    const { error } = await supabase.from("piezas_laminacion_seguimiento").upsert({
      obra_id: obraId, pieza_id: pieza.pieza_id, pieza_num: pieza.num,
      estado, observaciones: obs.trim()||null, ubicacion: ubicacion.trim()||null,
      laminador: laminador.trim()||null,
      trayecto: trayecto.trim()||null,
      fecha_envio:     fechaEnvio     ? new Date(fechaEnvio + "T12:00:00").toISOString()     : null,
      fecha_recepcion: fechaRecepcion ? new Date(fechaRecepcion + "T12:00:00").toISOString() : null,
      updated_at: new Date().toISOString(), updated_by: user?.id ?? null,
    }, { onConflict: "obra_id,pieza_id" });
    setSaving(false);
    if (error) { setUploadErr("Error al guardar: " + error.message); return; }
    onSave();
  }

  const showUbicacion = ["en_proceso","terminada","entregada"].includes(estado);
  const piezaLabel = pieza.sub != null ? `#${String(pieza.num).padStart(2,"0")} · ${pieza.sub}` : `#${String(pieza.num).padStart(2,"0")}`;

  const INP = {
    background:C.s0, border:`1px solid ${C.b0}`, color:C.t0,
    padding:"9px 12px", borderRadius:8, fontSize:13, outline:"none",
    width:"100%", fontFamily:C.sans, boxSizing:"border-box", transition:"border-color .15s",
  };

  return (
    <div onClick={e => e.target===e.currentTarget && !fotosBusy && !saving && onClose()} style={{ position:"fixed", inset:0, zIndex:9100, background:"var(--overlay-strong)", ...GLASS, display:"flex", alignItems:"flex-start", justifyContent:"center", padding:"40px 20px", overflowY:"auto" }}>

      <div role="dialog" aria-modal="true" aria-label={`Detalle de ${pieza.desc}`} style={{ background:"var(--panel-solid)", border:`1px solid ${C.b1}`, borderRadius:14, width:"100%", maxWidth:720, fontFamily:C.sans, boxShadow:"0 32px 80px rgba(0,0,0,0.8)", animation:"plv-slideup .18s ease", marginBottom:40 }}>

        {/* header */}
        <div style={{ padding:"18px 20px 14px", borderBottom:`1px solid ${C.b0}`, display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
          <div>
            <div style={{ fontSize:10, letterSpacing:1.3, textTransform:"uppercase", color:C.t2, marginBottom:5 }}>
              {(lineaKey ?? "").toUpperCase()} · Pieza {piezaLabel}
              {pieza.matriz && <span style={{ marginLeft:8, color:C.cyan }}>✦ {pieza.matriz}</span>}
            </div>
            <div style={{ fontSize:17, fontWeight:600, color:C.t0, lineHeight:1.3 }}>{pieza.desc}</div>
          </div>
          <button onClick={onClose} disabled={fotosBusy || saving} aria-label="Cerrar detalle de pieza" style={{ background:"transparent", border:"none", color:C.t2, cursor:"pointer", fontSize:20, lineHeight:1, padding:"2px 6px", marginLeft:10 }}>×</button>
        </div>

        {/* body */}
        <div style={{ padding:"18px 20px 22px", display:"flex", flexDirection:"column", gap:14 }}>

          <PiezasLaminacionFotos pieza={pieza} obraId={obraId} lineaKey={lineaKey} imagenes={imagenes} onChange={onImagenesChange} onBusyChange={setFotosBusy} />

          {uploadErr && (
            <div style={{ padding:"8px 12px", borderRadius:7, background:"rgba(239,68,68,0.08)", border:"1px solid rgba(239,68,68,0.25)", fontSize:13, color:"#fca5a5" }}>
              ⚠ {uploadErr}
            </div>
          )}

          {/* estado */}
          <div>
            <label style={{ fontSize:10, letterSpacing:1.3, color:C.t1, display:"block", marginBottom:8, textTransform:"uppercase", fontWeight: 600 }}>Estado</label>
            <div style={{ display:"flex", flexWrap:"wrap", gap:6 }}>
              {Object.entries(EST).map(([key,e]) => (
                <button key={key} onClick={() => setEstado(key)} style={{ padding:"6px 13px", borderRadius:99, fontSize:12, fontWeight: 600, cursor:"pointer", border:estado===key?`1px solid ${e.border}`:`1px solid ${C.b0}`, background:estado===key?e.bg:"transparent", color:estado===key?e.color:C.t2, transition:"all .15s", fontFamily:C.sans }}>
                  {e.label}
                </button>
              ))}
            </div>
          </div>

          {/* laminador */}
          <div>
            <label style={{ fontSize:10, letterSpacing:1.3, color:C.t1, display:"block", marginBottom:6, textTransform:"uppercase", fontWeight: 600 }}>Laminador</label>
            <input value={laminador} onChange={e => setLaminador(e.target.value)} placeholder="Nombre del laminador responsable…" style={INP}
              onFocus={e => e.currentTarget.style.borderColor="rgba(59,130,246,0.4)"} onBlur={e => e.currentTarget.style.borderColor=C.b0} />
          </div>

          {/* ubicación */}
          {showUbicacion && (
            <div style={{ animation:"plv-fadeup .2s ease" }}>
              <label style={{ fontSize:10, letterSpacing:1.3, color:C.t1, display:"block", marginBottom:6, textTransform:"uppercase", fontWeight: 600 }}>¿Dónde está?</label>
              <input value={ubicacion} onChange={e => setUbicacion(e.target.value)} placeholder="Planta Pampa, en depósito, montada…" style={INP}
                onFocus={e => e.currentTarget.style.borderColor="rgba(59,130,246,0.4)"} onBlur={e => e.currentTarget.style.borderColor=C.b0} />
            </div>
          )}

          {/* trayecto / movimiento entre astilleros */}
          {(estado === "enviada" || estado === "recibida" || trayecto) && (
            <div style={{ animation:"plv-fadeup .2s ease" }}>
              <label style={{ fontSize:10, letterSpacing:1.3, color:C.t1, display:"block", marginBottom:6, textTransform:"uppercase", fontWeight: 600 }}>Trayecto / Movimiento</label>
              <input value={trayecto} onChange={e => setTrayecto(e.target.value)} placeholder="Ej: Planta Pampa → Astillero Norte" style={INP}
                onFocus={e => e.currentTarget.style.borderColor="rgba(34,211,238,0.4)"} onBlur={e => e.currentTarget.style.borderColor=C.b0} />
              <div style={{ fontSize:10, color:C.t2, marginTop:4, lineHeight:1.5 }}>
                Indicá el recorrido si la pieza va entre astilleros. Se puede actualizar en cada viaje.
              </div>
            </div>
          )}

          {/* fechas de envío y recepción */}
          {(estado === "enviada" || estado === "recibida" || fechaEnvio || fechaRecepcion) && (
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, animation:"plv-fadeup .2s ease" }}>
              <div>
                <label style={{ fontSize:10, letterSpacing:1.3, color:C.cyan, display:"block", marginBottom:6, textTransform:"uppercase", fontWeight: 600 }}>↗ Fecha de envío</label>
                <input type="date" value={fechaEnvio} onChange={e => setFechaEnvio(e.target.value)}
                  style={{ ...INP, colorScheme:"var(--input-color-scheme, dark)" }}
                  onFocus={e => e.currentTarget.style.borderColor="rgba(34,211,238,0.4)"} onBlur={e => e.currentTarget.style.borderColor=C.b0} />
              </div>
              <div>
                <label style={{ fontSize:10, letterSpacing:1.3, color:"#2dd4bf", display:"block", marginBottom:6, textTransform:"uppercase", fontWeight: 600 }}>↙ Fecha de recepción</label>
                <input type="date" value={fechaRecepcion} onChange={e => setFechaRecepcion(e.target.value)}
                  style={{ ...INP, colorScheme:"var(--input-color-scheme, dark)" }}
                  onFocus={e => e.currentTarget.style.borderColor="rgba(45,212,191,0.4)"} onBlur={e => e.currentTarget.style.borderColor=C.b0} />
              </div>
            </div>
          )}

          {/* observaciones */}
          <div>
            <label style={{ fontSize:10, letterSpacing:1.3, color:C.t1, display:"block", marginBottom:6, textTransform:"uppercase", fontWeight: 600 }}>Observaciones</label>
            <textarea value={obs} onChange={e => setObs(e.target.value)} rows={3} placeholder="Fecha, problema encontrado, detalles…"
              style={{ ...INP, resize:"vertical", lineHeight:1.6 }}
              onFocus={e => e.currentTarget.style.borderColor="rgba(59,130,246,0.4)"} onBlur={e => e.currentTarget.style.borderColor=C.b0} />
          </div>

          {/* acciones */}
          <div style={{ display:"flex", gap:8, justifyContent:"flex-end", paddingTop:2 }}>
            <button onClick={onClose} disabled={fotosBusy || saving} style={{ border:`1px solid ${C.b0}`, background:"transparent", color:C.t1, padding:"7px 16px", borderRadius:8, cursor:"pointer", fontSize:13, fontFamily:C.sans }}>Cerrar</button>
            <button onClick={guardar} disabled={saving || fotosBusy} style={{ border:"1px solid rgba(59,130,246,0.35)", background:"rgba(59,130,246,0.15)", color:"#60a5fa", padding:"7px 20px", borderRadius:8, cursor:saving?"not-allowed":"pointer", fontSize:13, fontWeight:600, fontFamily:C.sans, opacity:saving?0.5:1 }}>
              {saving ? "Guardando…" : "Guardar"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── main ─────────────────────────────────────────────────────────────────────
export default function PiezasLaminacionView({ obras=[], esGestion=false }) {
  const { isMobile } = useResponsive();
  const [obraSelId,   setObraSelId]   = useState(null);
  const [seguimiento, setSeguimiento] = useState([]);
  const [seguimientoResumen, setSeguimientoResumen] = useState({});
  const [imagenesMap, setImagenesMap] = useState({});
  const [loading,     setLoading]     = useState(false);
  const [piezaModal,  setPiezaModal]  = useState(null);
  const [q,           setQ]           = useState("");
  const [filtroEst,   setFiltroEst]   = useState("todos");
  const [filtroMat,   setFiltroMat]   = useState("todos");
  const [saving,      setSaving]      = useState(false);
  const [flash,       setFlash]       = useState(null);
  const [qObra,       setQObra]       = useState("");
  const [selected,    setSelected]    = useState(new Set());
  const [k52Variant,  setK52Variant]  = useState(null); // null | "softop" | "hardtop"
  const [vistaModo,   setVistaModo]   = useState("recepcion");

  const obraSel  = useMemo(() => obras.find(o => o.id === obraSelId) ?? null, [obras, obraSelId]);
  const lineaKey = useMemo(() => detectarLinea(obraSel), [obraSel]);
  const catalogo = useMemo(() => lineaKey ? CATALOGOS[lineaKey] : null, [lineaKey]);

  // Sincroniza la selección inicial con las obras que llegan de la base.
  // eslint-disable-next-line react-hooks/set-state-in-effect
  useEffect(() => { if (!obraSelId && obras.length > 0) setObraSelId(obras[0].id); }, [obras, obraSelId]);
  // Reinicia los filtros locales al cambiar de obra.
  // eslint-disable-next-line react-hooks/set-state-in-effect
  useEffect(() => { setSelected(new Set()); setQ(""); setFiltroEst("todos"); setK52Variant(null); }, [obraSelId]);

  const cargarResumen = useCallback(async () => {
    const ids = obras.map(o => o.id).filter(Boolean);
    if (!ids.length) { setSeguimientoResumen({}); return; }
    const { data } = await supabase
      .from("piezas_laminacion_seguimiento")
      .select("obra_id,pieza_id,estado")
      .in("obra_id", ids);
    const map = {};
    for (const row of data ?? []) {
      const obraId = row.obra_id;
      const piezaId = row.pieza_id ?? String(row.pieza_num);
      if (!map[obraId]) map[obraId] = {};
      map[obraId][piezaId] = row.estado ?? "pendiente";
    }
    setSeguimientoResumen(map);
  }, [obras]);

  // eslint-disable-next-line react-hooks/set-state-in-effect
  useEffect(() => { cargarResumen(); }, [cargarResumen]);

  const cargar = useCallback(async () => {
    if (!obraSelId) return;
    setLoading(true);
    const [{ data:seg }, { data:imgs }] = await Promise.all([
      supabase.from("piezas_laminacion_seguimiento").select("*").eq("obra_id", obraSelId),
      supabase.from("piezas_laminacion_imagenes").select("*").eq("obra_id", obraSelId),
    ]);
    setSeguimiento(seg ?? []);
    const rawImgs = imgs ?? [];
    if (rawImgs.length > 0) {
      const withUrls = await Promise.all(
        rawImgs.map(img =>
          supabase.storage.from(STORAGE_BUCKET).createSignedUrl(img.storage_path, 3600)
            .then(({ data }) => ({ ...img, url: data?.signedUrl ?? null }))
        )
      );
      const map = {};
      for (const img of withUrls) {
        const key = img.pieza_id ?? String(img.pieza_num);
        if (!map[key]) map[key] = [];
        map[key].push(img);
      }
      setImagenesMap(map);
    } else { setImagenesMap({}); }
    setLoading(false);
  }, [obraSelId]);

  // Carga datos externos para la obra seleccionada.
  // eslint-disable-next-line react-hooks/set-state-in-effect
  useEffect(() => { cargar(); }, [cargar]);

  useEffect(() => {
    if (!obraSelId) return;
    const ch = supabase.channel(`plv-${obraSelId}`)
      .on("postgres_changes", { event:"*", schema:"public", table:"piezas_laminacion_seguimiento", filter:`obra_id=eq.${obraSelId}` }, cargar)
      .on("postgres_changes", { event:"*", schema:"public", table:"piezas_laminacion_imagenes",    filter:`obra_id=eq.${obraSelId}` }, cargar)
      .subscribe();
    return () => supabase.removeChannel(ch);
  }, [obraSelId, cargar]);

  // MOVIDO PARA EVITAR TEMPORAL DEAD ZONE
  const segMap = useMemo(() => {
    const m = {};
    for (const r of seguimiento) { const key = r.pieza_id ?? String(r.pieza_num); m[key] = r; }
    return m;
  }, [seguimiento]);

  const obrasFiltradas = useMemo(() => {
    const qq = qObra.trim().toLowerCase();
    if (!qq) return obras;
    return obras.filter(o => (o.codigo??o.nombre??"").toLowerCase().includes(qq) || (o.linea_nombre??"").toLowerCase().includes(qq));
  }, [obras, qObra]);

  const obrasPorLinea = useMemo(() => {
    const groups = {};
    for (const key of LINE_ORDER) groups[key] = [];
    for (const obra of obrasFiltradas) {
      const resumen = resumenObraPiezas(obra, seguimientoResumen);
      const key = resumen.linea;
      if (!groups[key]) groups[key] = [];
      groups[key].push({ obra, resumen });
    }
    for (const key of Object.keys(groups)) {
      groups[key].sort((a, b) => (b.resumen.pct - a.resumen.pct) || String(a.obra.codigo ?? a.obra.nombre ?? "").localeCompare(String(b.obra.codigo ?? b.obra.nombre ?? "")));
    }
    return groups;
  }, [obrasFiltradas, seguimientoResumen]);

  const catalogoFiltradoVariant = useMemo(() => {
    if (!catalogo) return [];
    if (lineaKey !== "k52" || !k52Variant) return catalogo;
    return catalogo.filter(p => p.variant === null || p.variant === k52Variant);
  }, [catalogo, lineaKey, k52Variant]);

  const TOTAL = catalogoFiltradoVariant.length;

  const stats = useMemo(() => {
    if (!catalogoFiltradoVariant.length) return { byEst:{}, terminadas:0, pct:0 };
    const byEst = {};
    for (const k of Object.keys(EST)) byEst[k] = 0;
    for (const p of catalogoFiltradoVariant) { 
        const est = segMap[p.pieza_id]?.estado ?? "pendiente"; 
        byEst[est] = (byEst[est]??0)+1; 
    }
    const terminadas = (byEst.terminada??0) + (byEst.entregada??0);
    return { byEst, terminadas, pct: TOTAL ? Math.round(terminadas/TOTAL*100) : 0 };
  }, [segMap, catalogoFiltradoVariant, TOTAL]);

  const piezasFiltradas = useMemo(() => {
    if (!catalogoFiltradoVariant.length) return [];
    const qq = q.trim().toLowerCase();
    return catalogoFiltradoVariant.filter(p => {
      const est = segMap[p.pieza_id]?.estado ?? "pendiente";
      if (filtroEst !== "todos" && est !== filtroEst) return false;
      if (filtroMat === "nueva"    && !p.matriz) return false;
      if (filtroMat === "estandar" &&  p.matriz) return false;
      if (qq && !p.desc.toLowerCase().includes(qq) && !p.pieza_id.includes(qq) && !String(p.num).includes(qq)) return false;
      return true;
    });
  }, [q, filtroEst, filtroMat, segMap, catalogoFiltradoVariant]);

  const recepcionGroups = useMemo(() => {
    const groups = { laminacion:[], listas:[], transito:[], recibidas:[], problemas:[] };
    for (const pieza of piezasFiltradas) {
      const estado = segMap[pieza.pieza_id]?.estado ?? "pendiente";
      if (estado === "problema") groups.problemas.push(pieza);
      else if (estado === "terminada") groups.listas.push(pieza);
      else if (estado === "enviada") groups.transito.push(pieza);
      else if (estado === "recibida" || estado === "entregada") groups.recibidas.push(pieza);
      else groups.laminacion.push(pieza);
    }
    return groups;
  }, [piezasFiltradas, segMap]);

  const selectedIds = useMemo(() => [...selected], [selected]);
  const allVisibleSelected = piezasFiltradas.length > 0 && piezasFiltradas.every(p => selected.has(p.pieza_id));
  const someSelected = selectedIds.length > 0;

  function toggleSelect(id) { setSelected(prev => { const n=new Set(prev); n.has(id)?n.delete(id):n.add(id); return n; }); }
  function toggleSelectAll() {
    if (allVisibleSelected) { setSelected(prev => { const n=new Set(prev); piezasFiltradas.forEach(p=>n.delete(p.pieza_id)); return n; }); }
    else { setSelected(prev => { const n=new Set(prev); piezasFiltradas.forEach(p=>n.add(p.pieza_id)); return n; }); }
  }
  function clearSelection() { setSelected(new Set()); }

  async function cambiarEstado(ids, nuevoEstado) {
    if (!obraSelId || !ids.length) return;
    setSaving(true);
    const { data:{ session } } = await supabase.auth.getSession().catch(() => ({ data:{ session:null } }));
    const user = session?.user ?? null;
    const byId = {};
    (catalogo??[]).forEach(p => { byId[p.pieza_id] = p; });

    const ahora = new Date().toISOString();
    const extras = {};
    if (nuevoEstado === "enviada")  extras.fecha_envio     = ahora;
    if (nuevoEstado === "recibida") extras.fecha_recepcion = ahora;

    const { error } = await supabase.from("piezas_laminacion_seguimiento").upsert(
      ids.map(id => ({ obra_id:obraSelId, pieza_id:id, pieza_num:byId[id]?.num??null, estado:nuevoEstado, updated_at:ahora, updated_by:user?.id??null, ...extras })),
      { onConflict:"obra_id,pieza_id" }
    );

    setSaving(false);

    if (error) {
      // Columna pieza_id no existe todavía → mostrar SQL al usuario
      const esMigracion = error.message?.includes("pieza_id") || error.message?.includes("column") || error.code === "42703" || error.code === "23505";
      showFlash(
        esMigracion
          ? "⚠ Falta migración SQL. Ver comentario al inicio del archivo."
          : "✗ Error: " + error.message,
        true
      );
      return;
    }

    showFlash(`✓ ${ids.length} pieza${ids.length>1?"s":""} → ${EST[nuevoEstado].label}`);
    clearSelection(); cargar(); cargarResumen();
  }

  function showFlash(msg, isError = false) { setFlash({ msg, isError }); setTimeout(() => setFlash(null), 3500); }

  const avanceColor = stats.pct >= 80 ? C.green : stats.pct >= 40 ? C.cyan : C.blue;
  const lineaLabel  = lineaKey==="k55"?"K55":lineaKey==="k52"?"K52":lineaKey==="k43"?"K43":lineaKey==="k37"?"K37":null;
  const hasMat      = catalogoFiltradoVariant?.some(p => p.matriz);

  function exportCSV() {
    if (!catalogoFiltradoVariant.length) return;
    const obra = obraSel?.codigo ?? obraSel?.nombre ?? "obra";
    const varTag = k52Variant ? `_${k52Variant}` : "";
    const rows = [["N° Pieza","Descripción","Estado","Laminador","Ubicación","Observaciones","Matriz"]];
    for (const p of catalogoFiltradoVariant) {
      const seg = segMap[p.pieza_id];
      const est = seg?.estado ?? "pendiente";
      rows.push([
        p.sub != null ? `${p.num}.${p.sub}` : `${p.num}`,
        p.desc,
        EST[est]?.label ?? est,
        seg?.laminador ?? "",
        seg?.ubicacion ?? "",
        seg?.observaciones ?? "",
        p.matriz ?? "",
      ]);
    }
    const csv = rows.map(r => r.map(c => `"${String(c).replace(/"/g,'""')}"`).join(",")).join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type:"text/csv;charset=utf-8;" });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement("a");
    a.href = url; a.download = `piezas_${obra}${varTag}_${lineaKey}.csv`; a.click();
    URL.revokeObjectURL(url);
  }

  function exportPrint() {
    if (!catalogoFiltradoVariant.length) return;
    const obra      = obraSel?.codigo ?? obraSel?.nombre ?? "Obra";
    const obraName  = obraSel?.nombre ?? "";
    const varLabel  = k52Variant ? ` · ${k52Variant.charAt(0).toUpperCase()+k52Variant.slice(1)}` : "";
    const fecha     = new Date().toLocaleDateString("es-AR", { day:"2-digit", month:"long", year:"numeric" });

    // Si hay piezas seleccionadas, exportar solo esas; si no, todas las filtradas
    const piezasExport = someSelected
      ? catalogoFiltradoVariant.filter(p => selected.has(p.pieza_id))
      : piezasFiltradas;
    const modoSeleccion = someSelected;
    const TOTAL_EXP = piezasExport.length;

    const EST_PRINT = {
      pendiente:  { label:"Pendiente",  color:"#64748b", border:"#94a3b8" },
      en_proceso: { label:"En proceso", color:"#1d4ed8", border:"#3b82f6" },
      terminada:  { label:"Terminada",  color:"#15803d", border:"#22c55e" },
      enviada:    { label:"Enviada",    color:"#0e7490", border:"#22d3ee" },
      recibida:   { label:"Recibida",   color:"#0f766e", border:"#2dd4bf" },
      entregada:  { label:"Entregada",  color:"#5b21b6", border:"#8b5cf6" },
      problema:   { label:"Problema",   color:"#b91c1c", border:"#ef4444" },
    };

    // KPI chips — solo de las piezas que se exportan
    const byEstExp = {};
    for (const p of piezasExport) { const e = segMap[p.pieza_id]?.estado ?? "pendiente"; byEstExp[e] = (byEstExp[e]??0)+1; }
    const kpis = Object.entries(EST_PRINT).map(([k, e]) => {
      const cnt = byEstExp[k] ?? 0;
      if (cnt === 0) return "";
      return `<span style="display:inline-flex;align-items:center;gap:5px;padding:3px 9px;border:1.5px solid ${e.border};border-radius:4px;margin-right:4px">
        <b style="font-size:14px;color:${e.color}">${cnt}</b>
        <span style="font-size:7px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:${e.color}">${e.label}</span>
      </span>`;
    }).join("");

    const rows = piezasExport.map((p, i) => {
      const seg      = segMap[p.pieza_id];
      const est      = seg?.estado ?? "pendiente";
      const ep       = EST_PRINT[est] ?? EST_PRINT.pendiente;
      const numStr   = p.sub != null ? `${String(p.num).padStart(2,"0")}.${p.sub}` : String(p.num).padStart(2,"0");
      const rowBg    = i % 2 === 0 ? "#ffffff" : "#f9fafb";
      const fEnvio   = seg?.fecha_envio    ? new Date(seg.fecha_envio).toLocaleDateString("es-AR",{day:"2-digit",month:"2-digit",year:"2-digit"})    : "";
      const fRecep   = seg?.fecha_recepcion ? new Date(seg.fecha_recepcion).toLocaleDateString("es-AR",{day:"2-digit",month:"2-digit",year:"2-digit"}) : "";
      const tray     = seg?.trayecto ?? "";

      const matCell  = hasMat
        ? `<td style="padding:4px 7px;font-size:10px;color:#155e75;white-space:nowrap;border-right:1px solid #e5e7eb">${p.matriz ? `✦ ${p.matriz}` : ""}</td>`
        : "";

      const infoExtra = [
        seg?.laminador ? `<span style="color:#374151">${seg.laminador}</span>` : "",
        tray           ? `<span style="color:#155e75;font-style:italic">${tray}</span>` : "",
      ].filter(Boolean).join("  ·  ");

      const fechasCell = fEnvio || fRecep ? `
        ${fEnvio   ? `<span style="color:#0e7490">↗ ${fEnvio}</span>` : ""}
        ${fRecep   ? `<span style="color:#0f766e"> ↙ ${fRecep}</span>` : ""}
      ` : '<span style="color:#d1d5db">—</span>';

      return `<tr style="background:${rowBg}">
        <td style="padding:0;width:3px;border-left:3px solid ${ep.border}"></td>
        <td style="padding:4px 8px;font-family:'Courier New',monospace;font-size:11px;font-weight:700;color:#111827;white-space:nowrap;border-right:1px solid #e5e7eb">${numStr}</td>
        <td style="padding:4px 10px;font-size:11px;color:#111827">
          <div>${p.desc}${p.variant ? ` <span style="font-size:7px;color:#6b7280;font-weight:700;text-transform:uppercase">${p.variant}</span>` : ""}</div>
          ${infoExtra ? `<div style="font-size:10px;margin-top:1px">${infoExtra}</div>` : ""}
        </td>
        ${matCell}
        <td style="padding:4px 8px;white-space:nowrap;border-left:1px solid #e5e7eb">
          <span style="font-size:10px;font-weight:700;color:${ep.color};text-transform:uppercase;letter-spacing:.4px;border-bottom:1.5px solid ${ep.border};padding-bottom:1px">${ep.label}</span>
        </td>
        <td style="padding:4px 8px;font-size:10px;color:#374151;border-left:1px solid #e5e7eb;white-space:nowrap">${fechasCell}</td>
        <td style="padding:4px 8px;font-size:10px;color:#6b7280;border-left:1px solid #e5e7eb;font-style:${seg?.observaciones?"normal":"italic"}">${seg?.observaciones ?? ""}</td>
      </tr>`;
    }).join("");

    const matHeader = hasMat
      ? `<th style="padding:5px 7px;text-align:left;font-size:7px;letter-spacing:1.5px;text-transform:uppercase;color:#9ca3af;border-right:1px solid #e5e7eb;white-space:nowrap">Matriz</th>`
      : "";

    const subtitulo = modoSeleccion
      ? `${TOTAL_EXP} piezas seleccionadas · ${obraName && obraName!==obra ? obraName+"  ·  " : ""}${lineaLabel ? "Línea "+lineaLabel : ""}`
      : `${obraName && obraName!==obra ? obraName+"  ·  " : ""}${lineaLabel ? "Línea "+lineaLabel+"  ·  " : ""}${TOTAL} piezas`;

    const html = `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>${modoSeleccion?"Remito":"Seguimiento"} · ${obra}</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
  <style>
    *{box-sizing:border-box;margin:0;padding:0}
    body{font-family:'Inter',system-ui,sans-serif;color:#111827;background:#fff;font-size:12px}
    .page{padding:18px 20px 14px}
    .header{display:flex;justify-content:space-between;align-items:flex-end;padding-bottom:8px;border-bottom:2px solid #111827;margin-bottom:10px}
    .h-left .eyebrow{font-size:7px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:#9ca3af;margin-bottom:3px}
    .h-left .title{font-size:18px;font-weight:900;color:#111827;letter-spacing:-.5px;line-height:1}
    .h-left .sub{font-size:10px;color:#6b7280;margin-top:3px}
    .h-right{text-align:right;flex-shrink:0;padding-left:20px}
    .h-right .linea{font-size:28px;font-weight:900;color:#111827;letter-spacing:-2px;line-height:1}
    .h-right .date{font-size:10px;color:#9ca3af;margin-top:2px}
    .summary{display:flex;align-items:center;gap:12px;margin-bottom:8px;padding:6px 10px;background:#f9fafb;border-radius:5px;border:1px solid #e5e7eb}
    .kpis{flex:1;display:flex;flex-wrap:wrap;gap:4px;align-items:center}
    .table-wrap{border:1px solid #e5e7eb;border-radius:4px;overflow:hidden}
    table{width:100%;border-collapse:collapse}
    thead th{padding:5px 8px;background:#f3f4f6;text-align:left;font-size:7px;letter-spacing:1.5px;text-transform:uppercase;color:#9ca3af;border-bottom:1px solid #e5e7eb;white-space:nowrap}
    tbody tr:last-child td{border-bottom:none}
    .footer{margin-top:8px;display:flex;justify-content:space-between}
    .footer span{font-size:7px;color:#9ca3af;letter-spacing:.3px}
    ${modoSeleccion ? `.remito-badge{display:inline-block;background:#cffafe;border:1.5px solid #22d3ee;color:#0e7490;font-size:7px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;padding:2px 8px;border-radius:3px;margin-left:8px;vertical-align:middle}` : ""}
    @media print{
      @page{size:A4 portrait;margin:8mm 10mm}
      body{-webkit-print-color-adjust:exact;print-color-adjust:exact}
      .page{padding:0}
    }
  </style>
</head>
<body>
<div class="page">
  <div class="header">
    <div class="h-left">
      <div class="eyebrow">Seguimiento de Laminación${modoSeleccion?" · REMITO / SELECCIÓN":""}</div>
      <div class="title">${obra}${varLabel}${modoSeleccion?'<span class="remito-badge">'+TOTAL_EXP+' piezas</span>':""}</div>
      <div class="sub">${subtitulo}</div>
    </div>
    <div class="h-right">
      <div class="linea">${lineaLabel ?? "LAM"}</div>
      <div class="date">${fecha}</div>
    </div>
  </div>

  <div class="summary">
    <div class="kpis">${kpis}</div>
    ${modoSeleccion ? `<div style="font-size:10px;color:#6b7280;flex-shrink:0">Selección de ${TOTAL_EXP} / ${TOTAL} piezas</div>` : ""}
  </div>

  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th style="width:3px;padding:0;border:none"></th>
          <th style="width:38px;border-right:1px solid #e5e7eb">N°</th>
          <th>Descripción / Laminador / Trayecto</th>
          ${matHeader}
          <th style="width:76px;border-left:1px solid #e5e7eb">Estado</th>
          <th style="width:100px;border-left:1px solid #e5e7eb">Envío · Recepción</th>
          <th style="border-left:1px solid #e5e7eb">Observaciones</th>
        </tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>
  </div>

  <div class="footer">
    <span>LAMINACIÓN · ${obra}${varLabel}${lineaLabel ? " · "+lineaLabel : ""}${modoSeleccion?" · SELECCIÓN":""}</span>
    <span>${fecha} · ${TOTAL_EXP} piezas · v5</span>
  </div>
</div>
<script>window.onload = () => { window.print(); }</script>
</body>
</html>`;

    const w = window.open("", "_blank");
    if (w) { w.document.write(html); w.document.close(); }
  }

  // Prevenir crashes si no hay obras cargadas todavía.
  if (!obras || obras.length === 0) {
    return (
      <div style={{ height:"100%", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", gap:12, padding:40, fontFamily:C.sans }}>
        <div style={{ width:52, height:52, borderRadius:"50%", background:C.s0, border:`1px solid ${C.b0}`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:22, color:C.t2 }}>◫</div>
        <div style={{ fontSize:15, fontWeight:600, color:C.t1 }}>No hay obras todavía</div>
        <div style={{ fontSize:13, color:C.t2, textAlign:"center", maxWidth:320, lineHeight:1.6 }}>
          Creá una obra desde la vista <b style={{ color:C.t1, fontWeight:600 }}>Obras</b> para empezar a seguir sus piezas de laminación.
        </div>
      </div>
    );
  }

  return (
    <>
      <style>{`
        @keyframes plv-kpi     { from{opacity:0;transform:scale(.94)} to{opacity:1;transform:scale(1)} }
        @keyframes plv-fadeup  { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:none} }
        @keyframes plv-slideup { from{opacity:0;transform:translateY(14px)} to{opacity:1;transform:none} }
        @keyframes plv-pulse   { 0%,100%{opacity:1} 50%{opacity:.3} }
        .plv-row { animation:plv-fadeup .25s ease both; }
        .plv-row:hover td { background:var(--panel)!important; }
        .plv-row td { transition:background .12s; }
        .plv-obra-btn { transition:all .15s; }
        .plv-obra-btn:hover { background:var(--panel)!important; }
        .plv-qbtn { transition:all .13s; }
        .plv-qbtn:hover { opacity:.8; }
        .plv-check { accent-color:#3b82f6; cursor:pointer; width:13px; height:13px; }
        .plv-row-sel td { background:rgba(59,130,246,0.05)!important; }
      `}</style>

      {flash && (
        <div style={{ position:"fixed", bottom:22, right:22, zIndex:9999, padding:"10px 18px", borderRadius:8, fontFamily:C.sans, fontSize:13, fontWeight:600, background: flash.isError ? "rgba(18,6,6,0.97)" : "rgba(6,18,12,0.97)", border: `1px solid ${flash.isError ? "rgba(239,68,68,.4)" : "rgba(16,185,129,.35)"}`, color: flash.isError ? C.red : C.green, animation:"plv-slideup .22s ease", boxShadow:"0 8px 32px rgba(0,0,0,.6)", maxWidth: 360 }}>
          {flash.msg}
        </div>
      )}

      <div style={{ display:"flex", flexDirection:"column", height:"100%", fontFamily:C.sans, minHeight:0 }}>

        {/* header */}
        <div style={{ padding:"9px 12px 8px", borderBottom:`1px solid ${C.b0}`, flexShrink:0 }}>
          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", gap:10, marginBottom:obraSel&&catalogo?8:0 }}>
            <div>
              <div style={{ fontSize:9, letterSpacing:1, textTransform:"uppercase", color:C.t2, marginBottom:3 }}>Laminación · Seguimiento de piezas</div>
              <h2 style={{ margin:0, fontSize:17, fontWeight:600, color:C.t0, lineHeight:1.2, fontFamily:C.mono, letterSpacing:.5 }}>
                {obraSel ? (obraSel.codigo??obraSel.nombre??"—") : "Piezas de Laminación"}
              </h2>
              {obraSel?.linea_nombre && <div style={{ fontSize:10, color:C.t2, marginTop:2, letterSpacing:.5 }}>{obraSel.linea_nombre}</div>}
            </div>
            {obraSel && catalogo && (
              <div style={{ display:"flex", alignItems:"center", gap:6, flexShrink:0 }}>
                <ProgressRing pct={stats.pct} size={30} stroke={3} color={avanceColor} />
                <div>
                  <div style={{ fontFamily:C.mono, fontSize:16, fontWeight:600, color:avanceColor, lineHeight:1 }}>{stats.pct}%</div>
                  <div style={{ fontSize:10, color:C.t2, marginTop:2 }}>{stats.terminadas}/{TOTAL} listas</div>
                </div>
              </div>
            )}
          </div>
          {obraSel && catalogo && (
            <div aria-label="Resumen de piezas" style={{ display:"grid", gridTemplateColumns:"repeat(5,minmax(68px,1fr))", gap:4, overflowX:"auto" }}>
              <KpiCard label="Terminadas" value={stats.byEst.terminada??0}  total={TOTAL} color={C.green}  delay={0}    />
              <KpiCard label="En proceso" value={stats.byEst.en_proceso??0} total={TOTAL} color={C.blue}   delay={0.06} />
              <KpiCard label="Entregadas" value={stats.byEst.entregada??0}  total={TOTAL} color={C.purple} delay={0.12} />
              <KpiCard label="Problemas"  value={stats.byEst.problema??0}   total={TOTAL} color={C.red}    delay={0.18} />
              <KpiCard label="Pendientes" value={stats.byEst.pendiente??0}  total={TOTAL} color={C.t2}     delay={0.24} />
            </div>
          )}
        </div>

        {/* body */}
        <div style={{ flex:1, overflow:"hidden", display:"grid", gridTemplateColumns: isMobile ? "1fr" : "320px 1fr", gridTemplateRows: isMobile ? "auto 1fr" : "1fr", minHeight:0 }}>

          {/* sidebar obras */}
          <div style={{ borderRight: isMobile ? "none" : `1px solid ${C.b0}`, borderBottom: isMobile ? `1px solid ${C.b0}` : "none", maxHeight: isMobile ? 168 : undefined, display:"flex", flexDirection:"column", overflow:"hidden" }}>
            <div style={{ padding:"10px 10px 8px", borderBottom:`1px solid ${C.b0}`, flexShrink:0 }}>
              <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:8 }}>
                <span style={{ fontSize:10, color:C.t2, letterSpacing:1.2, textTransform:"uppercase", fontWeight:650 }}>Obras por linea</span>
                <span style={{ fontSize:11, color:C.t2 }}>{obrasFiltradas.length}/{obras.length}</span>
              </div>
              <input value={qObra} onChange={e => setQObra(e.target.value)} placeholder="Buscar obra…"
                style={{ background:C.s0, border:`1px solid ${C.b0}`, color:C.t0, padding:"6px 10px", borderRadius:7, fontSize:12, outline:"none", width:"100%", boxSizing:"border-box", fontFamily:C.sans }} />
            </div>
            <div style={{ flex:1, overflowY:"auto", padding:"8px" }}>
              {obrasFiltradas.length===0 && <div style={{ padding:"28px 12px", textAlign:"center", color:C.t2, fontSize:12 }}>Sin obras</div>}
              {LINE_ORDER.filter(key => obrasPorLinea[key]?.length).map(key => {
                const meta = LINE_META[key] ?? LINE_META.otros;
                const items = obrasPorLinea[key];
                const total = items.reduce((acc, it) => acc + it.resumen.total, 0);
                const listas = items.reduce((acc, it) => acc + it.resumen.listas, 0);
                const pctLinea = total ? Math.round((listas / total) * 100) : 0;
                return (
                  <section key={key} style={{ marginBottom:12 }}>
                    <div style={{ display:"flex", alignItems:"center", gap:7, margin:"2px 2px 7px" }}>
                      <Dot color={meta.color} size={6} />
                      <div style={{ fontSize:11, color:C.t1, fontWeight:650, letterSpacing:1.4, textTransform:"uppercase" }}>{meta.label}</div>
                      <div style={{ marginLeft:"auto", fontSize:10, color:C.t2 }}>{items.length} obra{items.length>1?"s":""}</div>
                    </div>
                    <div style={{ height:3, background:"var(--panel-2)", borderRadius:99, overflow:"hidden", margin:"0 2px 7px" }}>
                      <div style={{ width:`${pctLinea}%`, height:"100%", background:meta.color, opacity:.75 }} />
                    </div>
                    <div style={{ display:"grid", gap:6 }}>
                      {items.map(({ obra:o, resumen }) => {
                        const sel = o.id === obraSelId;
                        const estadoColor = OBRA_COLOR[o.estado] ?? C.t2;
                        return (
                          <button key={o.id} onClick={() => setObraSelId(o.id)} className="plv-obra-btn"
                            style={{ width:"100%", textAlign:"left", padding:"10px", borderRadius:9, cursor:"pointer", fontFamily:C.sans, background:sel?"rgba(59,130,246,0.10)":"var(--panel)", border:sel?"1px solid rgba(59,130,246,0.55)":`1px solid ${C.b0}`, boxShadow:sel?"inset 0 0 0 1px rgba(59,130,246,0.18)":"none" }}>
                            <div style={{ display:"flex", alignItems:"center", gap:7 }}>
                              <Dot color={estadoColor} size={5} />
                              <span style={{ fontWeight:650, fontSize:13, color:sel?C.t0:C.t1, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap", flex:1, fontFamily:C.mono, letterSpacing:.4 }}>
                                {o.codigo??o.nombre??"-"}
                              </span>
                              <span style={{ fontSize:10, color:meta.color, fontFamily:C.mono }}>{resumen.pct}%</span>
                            </div>
                            <div style={{ display:"flex", alignItems:"center", gap:6, marginTop:7 }}>
                              <div style={{ position:"relative", flex:1, height:7, borderRadius:99, background:"var(--panel-2)", overflow:"hidden" }}>
                                <div style={{ position:"absolute", inset:"0 auto 0 0", width:`${resumen.pct}%`, background:`linear-gradient(90deg,${meta.color}55,${meta.color})` }} />
                                <div style={{ position:"absolute", inset:"0 auto 0 0", width:`${resumen.pctRecibidas}%`, background:"#2dd4bf" }} />
                              </div>
                              {resumen.problemas > 0 && <span style={{ fontSize:10, color:C.red, fontFamily:C.mono }}>{resumen.problemas} obs</span>}
                            </div>
                            <div style={{ display:"flex", justifyContent:"space-between", gap:8, marginTop:6, fontSize:10, color:C.t2 }}>
                              <span>{resumen.recibidas}/{resumen.total || "-"} recibidas</span>
                              <span>{resumen.listas} listas/envio</span>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </section>
                );
              })}
            </div>
          </div>

          {/* tabla piezas */}
          <div style={{ display:"flex", flexDirection:"column", overflow:"hidden", minWidth:0 }}>
            {!obraSel ? (
              <div style={{ flex:1, display:"flex", alignItems:"center", justifyContent:"center" }}>
                <div style={{ fontSize:12, color:C.t2, letterSpacing:1.3, textTransform:"uppercase" }}>Seleccioná una obra</div>
              </div>
            ) : !catalogo ? (
              <div style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", gap:14, padding:40 }}>
                <div style={{ width:52, height:52, borderRadius:"50%", background:C.s0, border:`1px solid ${C.b0}`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:22, color:C.t2 }}>◎</div>
                <div style={{ fontSize:15, fontWeight:600, color:C.t1 }}>Sin plantilla de piezas</div>
                <div style={{ fontSize:13, color:C.t2, textAlign:"center", maxWidth:340, lineHeight:1.6 }}>
                  Esta obra no tiene catálogo. Hay plantillas para K37, K43, K52 y K55.
                </div>
                <div style={{ fontSize:11, color:C.t2, fontFamily:C.mono, padding:"6px 14px", borderRadius:6, background:C.s0, border:`1px solid ${C.b0}` }}>
                  Línea: {obraSel.linea_nombre??"sin asignar"} · Código: {obraSel.codigo??"—"}
                </div>
              </div>
            ) : (
              <>
                {/* toolbar */}
                <div style={{ padding:"9px 14px", borderBottom:`1px solid ${C.b0}`, display:"flex", gap:7, flexWrap:"wrap", alignItems:"center", flexShrink:0 }}>
                  {lineaLabel && (
                    <span style={{ fontSize:10, fontWeight:600, letterSpacing:1.1, padding:"3px 8px", borderRadius:4,
                      background: lineaKey==="k55"?"rgba(59,130,246,0.1)":lineaKey==="k52"?"rgba(139,92,246,0.1)":lineaKey==="k37"?"rgba(20,184,166,0.1)":"rgba(34,211,238,0.08)",
                      color:      lineaKey==="k55"?C.blue:lineaKey==="k52"?C.purple:lineaKey==="k37"?"#2dd4bf":C.cyan,
                      border:     `1px solid ${lineaKey==="k55"?"rgba(59,130,246,0.25)":lineaKey==="k52"?"rgba(139,92,246,0.25)":lineaKey==="k37"?"rgba(20,184,166,0.25)":"rgba(34,211,238,0.2)"}`,
                    }}>
                      {lineaLabel} · {TOTAL} piezas
                    </span>
                  )}

                  <div style={{ display:"flex", gap:3, background:"var(--panel)", border:`1px solid ${C.b0}`, borderRadius:7, padding:3 }}>
                    {[["recepcion","Recepcion"],["tabla","Tabla"]].map(([key,label]) => {
                      const active = vistaModo === key;
                      return (
                        <button key={key} onClick={() => setVistaModo(key)}
                          style={{ padding:"3px 10px", borderRadius:5, border: active ? "1px solid var(--border-2)" : "1px solid transparent",
                            background: active ? "var(--panel-2)" : "transparent", color: active ? C.t0 : C.t2,
                            fontSize:11, fontWeight:active?650:500, cursor:"pointer", fontFamily:C.sans }}>
                          {label}
                        </button>
                      );
                    })}
                  </div>

                  {/* K52 variant selector */}
                  {lineaKey === "k52" && (
                    <div style={{ display:"flex", gap:3, background:"var(--panel)", border:`1px solid ${C.b0}`, borderRadius:7, padding:3 }}>
                      {[["todos", null, "Todos"], ["softop", "softop", "Softop"], ["hardtop", "hardtop", "Hardtop"]].map(([key, val, label]) => {
                        const active = k52Variant === val;
                        const col = val === "softop" ? "#22d3ee" : val === "hardtop" ? C.violet : C.t1;
                        return (
                          <button key={key} onClick={() => setK52Variant(val)}
                            style={{ padding:"3px 10px", borderRadius:5, border: active ? `1px solid ${col}50` : "1px solid transparent",
                              background: active ? `${col}18` : "transparent",
                              color: active ? col : C.t2, fontSize:11, fontWeight:active?600:500,
                              cursor:"pointer", fontFamily:C.sans, transition:"all .15s", whiteSpace:"nowrap" }}>
                            {val === "softop" && "⛵ "}{val === "hardtop" && "🔧 "}{label}
                          </button>
                        );
                      })}
                    </div>
                  )}

                  <input value={q} onChange={e => setQ(e.target.value)} placeholder="Buscar pieza…"
                    style={{ background:C.s0, border:`1px solid ${C.b0}`, color:C.t0, padding:"5px 10px", borderRadius:6, fontSize:12, outline:"none", width:150, fontFamily:C.sans }} />
                  <select value={filtroEst} onChange={e => setFiltroEst(e.target.value)}
                    style={{ background:C.panelSolid, border:`1px solid ${C.b0}`, color:C.t1, padding:"5px 8px", borderRadius:6, fontSize:12, outline:"none", fontFamily:C.sans, cursor:"pointer" }}>
                    <option value="todos">Todos los estados</option>
                    {Object.entries(EST).map(([k,e]) => <option key={k} value={k}>{e.label} ({stats.byEst[k]??0})</option>)}
                  </select>
                  {hasMat && (
                    <select value={filtroMat} onChange={e => setFiltroMat(e.target.value)}
                      style={{ background:C.panelSolid, border:`1px solid ${C.b0}`, color:C.t1, padding:"5px 8px", borderRadius:6, fontSize:12, outline:"none", fontFamily:C.sans, cursor:"pointer" }}>
                      <option value="todos">Todas las matrices</option>
                      <option value="nueva">✦ Nueva</option>
                      <option value="estandar">Estándar</option>
                    </select>
                  )}
                  <div style={{ flex:1 }} />
                  <span style={{ fontSize:11, color:C.t2 }}>{piezasFiltradas.length}/{TOTAL}</span>
                  {vistaModo === "recepcion" && piezasFiltradas.length > 0 && (
                    <button onClick={allVisibleSelected ? clearSelection : toggleSelectAll}
                      style={{ border:`1px solid ${C.b0}`, background:"var(--panel)", color:C.t1, padding:"4px 9px", borderRadius:6, cursor:"pointer", fontSize:11, fontWeight: 600, fontFamily:C.sans }}>
                      {allVisibleSelected ? "Limpiar sel." : "Seleccionar visibles"}
                    </button>
                  )}

                  {/* export buttons */}
                  <div style={{ display:"flex", gap:4 }}>
                    <button onClick={exportCSV} title="Exportar CSV"
                      style={{ border:`1px solid rgba(16,185,129,0.3)`, background:"rgba(16,185,129,0.07)", color:"#34d399", padding:"4px 10px", borderRadius:6, cursor:"pointer", fontSize:11, fontWeight: 600, fontFamily:C.sans, display:"flex", alignItems:"center", gap:4 }}>
                      ↓ CSV
                    </button>
                    <button onClick={exportPrint} title={someSelected ? `Imprimir ${selectedIds.length} seleccionadas` : "Imprimir todas"}
                      style={{ border:`1px solid rgba(59,130,246,0.3)`, background:"rgba(59,130,246,0.07)", color:"#60a5fa", padding:"4px 10px", borderRadius:6, cursor:"pointer", fontSize:11, fontWeight: 600, fontFamily:C.sans, display:"flex", alignItems:"center", gap:4 }}>
                      🖨 {someSelected ? `PDF (${selectedIds.length})` : "PDF"}
                    </button>
                  </div>

                  {esGestion && someSelected && (
                    <div style={{ display:"flex", gap:5, alignItems:"center", padding:"3px 10px", borderRadius:7, background:"rgba(59,130,246,0.06)", border:"1px solid rgba(59,130,246,0.2)", animation:"plv-fadeup .18s ease" }}>
                      <span style={{ fontSize:11, color:C.blue, fontFamily:C.mono, marginRight:4 }}>{selectedIds.length} sel.</span>
                      {[["en_proceso","▶ En proceso","rgba(59,130,246,0.35)","rgba(59,130,246,0.12)","#60a5fa"],
                        ["terminada","✓ Terminadas","rgba(16,185,129,0.35)","rgba(16,185,129,0.1)","#34d399"],
                        ["entregada","↗ Entregadas","rgba(139,92,246,0.35)","rgba(139,92,246,0.1)","#a78bfa"],
                        ["pendiente","○ Pendiente",C.b0,"transparent",C.t2]
                      ].map(([est,lbl,border,bg,color]) => (
                        <button key={est} className="plv-qbtn" onClick={() => cambiarEstado(selectedIds, est)} disabled={saving}
                          style={{ border:`1px solid ${border}`, background:bg, color, padding:"3px 9px", borderRadius:5, cursor:"pointer", fontSize:11, fontWeight: 600, fontFamily:C.sans }}>
                          {lbl}
                        </button>
                      ))}
                      <button className="plv-qbtn" onClick={() => cambiarEstado(selectedIds, "enviada")} disabled={saving}
                        style={{ border:"1px solid rgba(34,211,238,0.35)", background:"rgba(34,211,238,0.1)", color:C.cyan, padding:"3px 9px", borderRadius:5, cursor:"pointer", fontSize:11, fontWeight: 600, fontFamily:C.sans }}>
                        Enviar
                      </button>
                      <button className="plv-qbtn" onClick={() => cambiarEstado(selectedIds, "recibida")} disabled={saving}
                        style={{ border:"1px solid rgba(45,212,191,0.35)", background:"rgba(45,212,191,0.1)", color:"#2dd4bf", padding:"3px 9px", borderRadius:5, cursor:"pointer", fontSize:11, fontWeight: 600, fontFamily:C.sans }}>
                        Recibir
                      </button>
                      <button onClick={clearSelection} style={{ background:"transparent", border:"none", color:C.t2, cursor:"pointer", fontSize:14, padding:"0 3px", lineHeight:1 }}>×</button>
                    </div>
                  )}

                  {esGestion && !someSelected && piezasFiltradas.length > 0 && (
                    <div style={{ display:"flex", gap:5 }}>
                      <button className="plv-qbtn" onClick={() => cambiarEstado(piezasFiltradas.map(p=>p.pieza_id),"en_proceso")} disabled={saving}
                        style={{ border:"1px solid rgba(59,130,246,0.3)", background:"rgba(59,130,246,0.07)", color:"#60a5fa", padding:"4px 10px", borderRadius:6, cursor:"pointer", fontSize:11, fontWeight: 600, fontFamily:C.sans }}>→ En proceso</button>
                      <button className="plv-qbtn" onClick={() => cambiarEstado(piezasFiltradas.map(p=>p.pieza_id),"terminada")} disabled={saving}
                        style={{ border:"1px solid rgba(16,185,129,0.3)", background:"rgba(16,185,129,0.07)", color:"#34d399", padding:"4px 10px", borderRadius:6, cursor:"pointer", fontSize:11, fontWeight: 600, fontFamily:C.sans }}>✓ Terminadas</button>
                    </div>
                  )}
                </div>

                {/* tabla */}
                <div style={{ flex:1, overflow:"hidden", minHeight:0 }}>
                  {loading ? (
                    <Cargando />
                  ) : vistaModo === "recepcion" ? (
                    <div style={{ height:"100%", display:"grid", gridTemplateColumns:"repeat(5,minmax(190px,1fr))", overflowX:"auto", minHeight:0 }}>
                      <RecepcionColumn title="Laminacion" subtitle="Pendientes o en proceso dentro del galpon de laminacion." color={C.blue}
                        piezas={recepcionGroups.laminacion} segMap={segMap} imagenesMap={imagenesMap} esGestion={esGestion} saving={saving}
                        selected={selected} onToggle={toggleSelect} onEstado={cambiarEstado} onDetalle={setPiezaModal} />
                      <RecepcionColumn title="Listas" subtitle="Piezas terminadas, pendientes de envio a construccion." color={C.green}
                        piezas={recepcionGroups.listas} segMap={segMap} imagenesMap={imagenesMap} esGestion={esGestion} saving={saving}
                        selected={selected} onToggle={toggleSelect} onEstado={cambiarEstado} onDetalle={setPiezaModal} />
                      <RecepcionColumn title="En transito" subtitle="Ya salieron de laminacion y esperan recepcion." color={C.cyan}
                        piezas={recepcionGroups.transito} segMap={segMap} imagenesMap={imagenesMap} esGestion={esGestion} saving={saving}
                        selected={selected} onToggle={toggleSelect} onEstado={cambiarEstado} onDetalle={setPiezaModal} />
                      <RecepcionColumn title="Recibidas" subtitle="Recepcionadas por construccion o ya entregadas." color="#2dd4bf"
                        piezas={recepcionGroups.recibidas} segMap={segMap} imagenesMap={imagenesMap} esGestion={esGestion} saving={saving}
                        selected={selected} onToggle={toggleSelect} onEstado={cambiarEstado} onDetalle={setPiezaModal} />
                      <RecepcionColumn title="Observadas" subtitle="Con problema abierto o pendiente de definicion." color={C.red}
                        piezas={recepcionGroups.problemas} segMap={segMap} imagenesMap={imagenesMap} esGestion={esGestion} saving={saving}
                        selected={selected} onToggle={toggleSelect} onEstado={cambiarEstado} onDetalle={setPiezaModal} />
                    </div>
                  ) : (
                    <div style={{ height:"100%", overflowY:"auto" }}>
                    <table style={{ width:"100%", borderCollapse:"collapse" }}>
                      <thead style={{ position:"sticky", top:0, zIndex:2 }}>
                        <tr style={{ background:C.panelSolid2 }}>
                          <th style={{ padding:"8px 10px 8px 14px", borderBottom:`1px solid ${C.b0}`, width:28 }}>
                            <input type="checkbox" className="plv-check" checked={allVisibleSelected} onChange={toggleSelectAll} />
                          </th>
                          {["N° pieza","Descripción",...(hasMat?["Matriz"]:[]),"Estado","Laminador","Ubicación","Fotos","Obs.",""].map(h => (
                            <th key={h} style={{ padding:"8px 12px", textAlign:"left", fontSize:10, color:C.t2, letterSpacing:1.3, textTransform:"uppercase", borderBottom:`1px solid ${C.b0}`, fontWeight: 600, whiteSpace:"nowrap" }}>{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {piezasFiltradas.map(pieza => {
                          const seg       = segMap[pieza.pieza_id];
                          const estado    = seg?.estado ?? "pendiente";
                          const imgs      = imagenesMap[pieza.pieza_id] ?? [];
                          const isSel     = selected.has(pieza.pieza_id);
                          const ubicacion = seg?.ubicacion;
                          const laminador = seg?.laminador;
                          const estInfo   = EST[estado] ?? EST.pendiente;
                          const numLabel  = pieza.sub != null
                            ? <><span style={{ fontFamily:C.mono, fontSize:11, color:C.t2 }}>{String(pieza.num).padStart(2,"0")}</span><span style={{ color:C.cyan, fontFamily:C.mono, fontSize:11 }}> · {pieza.sub}</span></>
                            : <span style={{ fontFamily:C.mono, fontSize:11, color:C.t2 }}>{String(pieza.num).padStart(2,"0")}</span>;
                          const variantBadge = pieza.variant === "softop"
                            ? <span style={{ fontSize:7, fontWeight:600, letterSpacing:1, padding:"1px 5px", borderRadius:3, background:"rgba(34,211,238,0.10)", color:"#22d3ee", border:"1px solid rgba(34,211,238,0.25)", marginLeft:4, whiteSpace:"nowrap" }}>SOFTOP</span>
                            : pieza.variant === "hardtop"
                            ? <span style={{ fontSize:7, fontWeight:600, letterSpacing:1, padding:"1px 5px", borderRadius:3, background:"rgba(34,211,238,0.10)", color:C.cyan, border:"1px solid rgba(34,211,238,0.25)", marginLeft:4, whiteSpace:"nowrap" }}>HARDTOP</span>
                            : null;

                          return (
                            <tr key={pieza.pieza_id} className={`plv-row${isSel?" plv-row-sel":""}`}
                              style={{ background:estado==="problema"?"rgba(239,68,68,0.03)":"transparent" }}>

                              <td style={{ padding:"8px 10px 8px 14px", borderBottom:`1px solid var(--panel)`, verticalAlign:"middle", borderLeft:`2px solid ${estInfo.color}` }} onClick={e => e.stopPropagation()}>
                                <input type="checkbox" className="plv-check" checked={isSel} onChange={() => toggleSelect(pieza.pieza_id)} />
                              </td>
                              <td style={{ padding:"10px 10px", borderBottom:`1px solid var(--panel)`, verticalAlign:"middle", whiteSpace:"nowrap" }}>{numLabel}</td>
                              <td style={{ padding:"10px 12px", borderBottom:`1px solid var(--panel)`, verticalAlign:"middle", maxWidth:220 }}>
                                <button onClick={() => setPiezaModal(pieza)}
                                  style={{ background:"transparent", border:"none", cursor:"pointer", textAlign:"left", padding:0, fontFamily:C.sans, display:"flex", alignItems:"center", flexWrap:"wrap", gap:2 }}
                                  onMouseEnter={e => e.currentTarget.querySelector("span").style.color=C.t0}
                                  onMouseLeave={e => e.currentTarget.querySelector("span").style.color=C.t1}>
                                  <span style={{ fontSize:13, fontWeight:500, color:C.t1, display:"block", transition:"color .15s" }}>{pieza.desc}</span>
                                  {variantBadge}
                                </button>
                              </td>

                              {hasMat && (
                                <td style={{ padding:"10px 12px", borderBottom:`1px solid var(--panel)`, verticalAlign:"middle" }}>
                                  {pieza.matriz
                                    ? <span style={{ fontSize:10, letterSpacing:1, padding:"2px 7px", borderRadius:99, background:"rgba(34,211,238,0.09)", color:C.cyan, border:"1px solid rgba(34,211,238,0.2)", fontWeight:600, whiteSpace:"nowrap" }}>✦ {pieza.matriz}</span>
                                    : <span style={{ opacity:0.15, fontSize:11 }}>—</span>}
                                </td>
                              )}

                              <td style={{ padding:"8px 12px", borderBottom:`1px solid var(--panel)`, verticalAlign:"middle" }}>
                                <div style={{ display:"flex", alignItems:"center", gap:5, flexWrap:"wrap" }}>
                                  <Dot color={EST[estado]?.color??C.t2} size={5} pulse={estado==="en_proceso"} />
                                  <Chip estado={estado} sm />
                                  {esGestion && (
                                    <div style={{ display:"flex", gap:2, marginLeft:2 }} onClick={e => e.stopPropagation()}>
                                      {estado !== "en_proceso" && (
                                        <button className="plv-qbtn" title="En proceso" onClick={() => cambiarEstado([pieza.pieza_id],"en_proceso")}
                                          style={{ width:20, height:20, border:"1px solid rgba(59,130,246,0.3)", background:"rgba(59,130,246,0.08)", color:"#60a5fa", borderRadius:4, cursor:"pointer", fontSize:10, display:"flex", alignItems:"center", justifyContent:"center" }}>▶</button>
                                      )}
                                      {estado !== "terminada" && (
                                        <button className="plv-qbtn" title="Terminada" onClick={() => cambiarEstado([pieza.pieza_id],"terminada")}
                                          style={{ width:20, height:20, border:"1px solid rgba(16,185,129,0.3)", background:"rgba(16,185,129,0.08)", color:"#34d399", borderRadius:4, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center" }}>
                                          <IconCheck size={10} />
                                        </button>
                                      )}
                                    </div>
                                  )}
                                </div>
                              </td>

                              <td style={{ padding:"10px 12px", borderBottom:`1px solid var(--panel)`, verticalAlign:"middle", maxWidth:130 }}>
                                {laminador
                                  ? <span style={{ fontSize:12, color:C.t1, display:"block", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }} title={laminador}>{laminador}</span>
                                  : <span style={{ opacity:0.18, fontSize:12 }}>—</span>}
                              </td>

                              <td style={{ padding:"10px 12px", borderBottom:`1px solid var(--panel)`, verticalAlign:"middle", maxWidth:130 }}>
                                {ubicacion
                                  ? <span style={{ fontSize:11, color:C.t1, display:"block", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }} title={ubicacion}>{ubicacion}</span>
                                  : <span style={{ opacity:0.18, fontSize:11 }}>—</span>}
                              </td>

                              <td style={{ padding:"8px 12px", borderBottom:`1px solid var(--panel)`, verticalAlign:"middle" }}>
                                <div style={{ display:"flex", gap:4, alignItems:"center" }}>
                                  {imgs.slice(0,3).map(img => <FotoPieza key={img.storage_path} foto={img} descripcion={pieza.desc} onClick={() => setPiezaModal(pieza)} style={{ width:72, height:56, flexShrink:0 }} />)}
                                  {imgs.length>3 && <span style={{ fontSize:10, color:C.t2, background:C.s1, border:`1px solid ${C.b0}`, borderRadius:5, padding:"2px 5px", fontFamily:C.mono }}>+{imgs.length-3}</span>}
                                  <button onClick={() => setPiezaModal(pieza)} aria-label={`Agregar fotos de ${pieza.desc}`} title="Agregar fotos de referencia"
                                    style={{ background:"transparent", border:`1px dashed ${C.b0}`, color:C.t2, width:28, height:28, borderRadius:5, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", transition:"border-color .15s", flexShrink:0 }}
                                    onMouseEnter={e => e.currentTarget.style.borderColor=C.b1}
                                    onMouseLeave={e => e.currentTarget.style.borderColor=C.b0}>
                                    {imgs.length===0 ? <IconCamera size={13} color={C.t2} /> : <span style={{ fontSize:14, lineHeight:1 }}>+</span>}
                                  </button>
                                </div>
                              </td>

                              <td style={{ padding:"10px 12px", borderBottom:`1px solid var(--panel)`, verticalAlign:"middle", maxWidth:150 }}>
                                {seg?.observaciones
                                  ? <span style={{ fontSize:12, color:C.t2, display:"block", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }} title={seg.observaciones}>{seg.observaciones}</span>
                                  : <span style={{ opacity:0.18, fontSize:12 }}>—</span>}
                              </td>

                              <td style={{ padding:"8px 12px", borderBottom:`1px solid var(--panel)`, verticalAlign:"middle" }}>
                                <button onClick={() => setPiezaModal(pieza)}
                                  style={{ border:`1px solid ${C.b0}`, background:"transparent", color:C.t2, padding:"3px 9px", borderRadius:5, cursor:"pointer", fontSize:11, fontFamily:C.sans, transition:"all .15s" }}
                                  onMouseEnter={e => { e.currentTarget.style.borderColor=C.b1; e.currentTarget.style.color=C.t0; }}
                                  onMouseLeave={e => { e.currentTarget.style.borderColor=C.b0; e.currentTarget.style.color=C.t2; }}>
                                  Detalle
                                </button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                    </div>
                  )}
                  {!loading && piezasFiltradas.length===0 && (
                    <div style={{ padding:"40px 20px", textAlign:"center" }}>
                      <div style={{ fontSize:13, color:C.t2 }}>Sin resultados</div>
                      {(q||filtroEst!=="todos"||filtroMat!=="todos") && (
                        <button onClick={() => { setQ(""); setFiltroEst("todos"); setFiltroMat("todos"); }}
                          style={{ marginTop:10, border:`1px solid ${C.b0}`, background:"transparent", color:C.t1, padding:"5px 12px", borderRadius:6, cursor:"pointer", fontSize:12, fontFamily:C.sans }}>
                          Limpiar filtros
                        </button>
                      )}
                    </div>
                  )}
                </div>

                {/* pie */}
                <div style={{ padding:"7px 14px", borderTop:`1px solid ${C.b0}`, flexShrink:0, display:"flex", alignItems:"center", gap:10 }}>
                  {someSelected && <span style={{ fontSize:11, color:C.blue, fontFamily:C.mono }}>{selectedIds.length} seleccionada{selectedIds.length>1?"s":""}</span>}
                  <div style={{ flex:1, height:3, background:"var(--panel)", borderRadius:99, overflow:"hidden" }}>
                    <div style={{ height:"100%", width:`${stats.pct}%`, background:`linear-gradient(90deg,${avanceColor}60,${avanceColor})`, borderRadius:99, transition:"width .6s ease" }} />
                  </div>
                  <span style={{ fontFamily:C.mono, fontSize:11, color:avanceColor, whiteSpace:"nowrap" }}>{stats.pct}% · {stats.terminadas}/{TOTAL}</span>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {piezaModal && (
        <PiezaModal
          key={`${obraSelId}-${piezaModal.pieza_id}`} pieza={piezaModal} lineaKey={lineaKey} obraId={obraSelId}
          segRow={segMap[piezaModal.pieza_id]}
          imagenes={imagenesMap[piezaModal.pieza_id] ?? []}
          onImagenesChange={fotos => setImagenesMap(prev => ({ ...prev, [piezaModal.pieza_id]:fotos }))}
          onSave={() => { setPiezaModal(null); showFlash("✓ Guardado"); cargar(); }}
          onClose={() => { setPiezaModal(null); cargar(); }}
        />
      )}
    </>
  );
}
